# -*- coding: ascii -*-
"""Install an owned Bzyk83 IPK using opkg; retain package hooks and dependencies."""
import io,os,re,shutil,struct,subprocess,sys,tarfile,tempfile,urllib.request as R,json,hashlib,urllib.parse as U
from pathlib import Path
LOG='/tmp/bzyk83_plugin_update.log'
PACKAGE='enigma2-plugin-extensions-bzyk83downloader'

def members(blob):
    if blob[:8]!=b'!<arch>\n':raise ValueError('Pobrany plik nie jest pakietem IPK.')
    pos=8;parts={}
    while pos<len(blob):
        h=blob[pos:pos+60]
        if len(h)!=60 or h[58:60]!=b'`\n':raise ValueError('Uszkodzony naglowek IPK.')
        name=h[:16].decode('ascii').strip().rstrip('/');size=int(h[48:58]);pos+=60
        if size<0 or pos+size>len(blob) or name in parts:raise ValueError('Uszkodzona zawartosc IPK.')
        parts[name]=blob[pos:pos+size];pos+=size+size%2
    if parts.get('debian-binary',b'').strip()!=b'2.0' or 'control.tar.gz' not in parts or 'data.tar.gz' not in parts:raise ValueError('Nieobslugiwany format IPK.')
    return parts

def metadata(parts):
    with tarfile.open(fileobj=io.BytesIO(parts['control.tar.gz']),mode='r:gz') as tar:
        entry=next((n for n in tar if n.isfile() and n.name.lstrip('./')=='control'),None)
        if entry is None:raise ValueError('Brak metadanych pakietu.')
        text=tar.extractfile(entry).read(256*1024).decode('utf-8')
    fields=dict(re.findall(r'(?m)^([A-Za-z][A-Za-z-]*):[ \t]*(.*)$',text))
    if fields.get('Package')!=PACKAGE:raise ValueError('Plik IPK nie jest pakietem Bzyk83Downloader.')
    if not fields.get('Version') or not fields.get('Architecture'):raise ValueError('Brak wersji lub architektury IPK.')
    return fields

def pack(parts):
    blob=bytearray(b'!<arch>\n')
    for name,data in parts.items():
        header=(name+'/').ljust(16)+'0'.ljust(12)+'0'.ljust(6)+'0'.ljust(6)+'100644'.ljust(8)+str(len(data)).ljust(10)+'`\n'
        blob.extend(header.encode('ascii'));blob.extend(data)
        if len(data)%2:blob.extend(b'\n')
    return bytes(blob)

def match_architecture(blob,listing):
    parts=members(blob);meta=metadata(parts);architectures=[]
    for line in listing.splitlines():
        fields=line.split()
        if len(fields)==3 and fields[0]=='arch':architectures.append((int(fields[2]),fields[1]))
    accepted={arch for priority,arch in architectures}
    if meta['Architecture'] in accepted:return blob,meta
    # The protected build uses CPython stable ABI and the same ARM32 hard-float
    # binaries on SF8008 OpenPLi/OpenATV. Only the opkg architecture label differs.
    candidates=[(priority,arch) for priority,arch in architectures if any(k in arch for k in ('cortexa15','armv7','armhf','sf8008'))]
    if not candidates:raise ValueError('Niezgodna architektura IPK: '+meta['Architecture'])
    native=0;core=False
    with tarfile.open(fileobj=io.BytesIO(parts['data.tar.gz']),mode='r:gz') as tar:
        for item in tar:
            if not item.isfile():continue
            if item.name.endswith(('.so','.abi3.so')):
                header=tar.extractfile(item).read(52)
                if len(header)!=52 or header[:5]!=b'\x7fELF\x01' or struct.unpack_from('<H',header,18)[0]!=40 or not struct.unpack_from('<I',header,36)[0]&0x400:raise ValueError('Niezgodny modul natywny w IPK.')
                if not item.name.endswith('.abi3.so'):raise ValueError('Modul wymaga innej wersji Pythona.')
                native+=1
                if item.name.endswith('/bzyk83-protected/bzyk83_secure.abi3.so'):core=True
    if not native or not core:raise ValueError('Niepotwierdzona zgodnosc ARM stable ABI.')
    arch=max(candidates)[1];output=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(parts['control.tar.gz']),mode='r:gz') as old:
        with tarfile.open(fileobj=output,mode='w:gz',format=tarfile.GNU_FORMAT) as new:
            for item in old:
                if not item.isfile():new.addfile(item);continue
                data=old.extractfile(item).read()
                if item.name.lstrip('./')=='control':data=re.sub(br'(?m)^Architecture:.*$',b'Architecture: '+arch.encode('ascii'),data);item.size=len(data)
                new.addfile(item,io.BytesIO(data))
    parts['control.tar.gz']=output.getvalue();meta['Architecture']=arch
    return pack(parts),meta

def newer(remote,local):
    remote=str(remote).strip().lstrip('vV');local=str(local).strip().lstrip('vV')
    valid=lambda v:bool(re.fullmatch(r'[0-9][A-Za-z0-9.+:~_-]*',v))
    if not valid(remote) or not valid(local):return False
    if shutil.which('opkg'):
        return subprocess.run(['opkg','compare-versions',remote,'>',local],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    # Host-only fallback; opkg is required for installation on receivers.
    parts=lambda v:tuple(int(n) for n in re.findall(r'\d+',v))
    return parts(remote)>parts(local)

def install(url):
    log=None
    try:
        log=open(LOG,'w',encoding='utf-8');log.write('Aktualizacja Bzyk83Downloader przez IPK\n');log.flush()
        if not shutil.which('opkg'):raise ValueError('Nie znaleziono opkg.')
        expected=None
        if url.endswith('.json'):
            req=R.Request(url,headers={'User-Agent':'Bzyk83Downloader-IPK','Cache-Control':'no-cache'})
            with R.urlopen(req,timeout=20) as response:expected=json.loads(response.read(16*1024))
            filename=expected.get('file','')
            if not re.fullmatch(r'bzyk83_[A-Za-z0-9._+-]+\.ipk',filename) or not re.fullmatch(r'[0-9a-f]{64}',expected.get('sha256','')):raise ValueError('Niepoprawny manifest aktualizacji IPK.')
            url=U.urljoin(url,filename)
        request=R.Request(url,headers={'User-Agent':'Bzyk83Downloader-IPK','Cache-Control':'no-cache'})
        with R.urlopen(request,timeout=30) as response:
            if not response.geturl().startswith('https://'):raise ValueError('Wymagane pobieranie przez HTTPS.')
            blob=response.read(64*1024*1024+1)
        if len(blob)>64*1024*1024:raise ValueError('Pakiet IPK jest zbyt duzy.')
        if expected and hashlib.sha256(blob).hexdigest()!=expected['sha256']:raise ValueError('Suma SHA-256 pakietu nie zgadza sie z manifestem.')
        if expected and metadata(members(blob))['Version']!=expected.get('version'):raise ValueError('Wersja pakietu nie zgadza sie z manifestem.')
        result=subprocess.run(['opkg','print-architecture'],capture_output=True,text=True,check=True)
        blob,meta=match_architecture(blob,result.stdout)
        log.write('Pakiet: %s; wersja: %s; architektura: %s\n'%(meta['Package'],meta['Version'],meta['Architecture']));log.flush()
        try:
            indexes=subprocess.run(['opkg','update'],stdout=log,stderr=subprocess.STDOUT,timeout=180)
            if indexes.returncode:log.write('Nie odswiezono wszystkich indeksow. Proba instalacji z dostepnymi listami.\n')
        except subprocess.TimeoutExpired:log.write('Limit czasu odswiezania indeksow; proba instalacji z dostepnymi listami.\n')
        with tempfile.TemporaryDirectory(prefix='bzyk83-ipk-') as tmp:
            path=Path(tmp)/'Bzyk83Downloader.ipk';path.write_bytes(blob)
            result=subprocess.run(['opkg','install',str(path)],stdout=log,stderr=subprocess.STDOUT)
            if result.returncode:
                log.write('\nInstalacja nieudana. W przypadku brakujacych zaleznosci wykonaj opkg update i ponow aktualizacje.\n');return False
        marker=Path('/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader/.ipk-transition-pending')
        if marker.is_file():marker.unlink()
        log.write('\nInstalacja IPK zakonczona poprawnie.\n');return True
    except Exception as error:
        if log:log.write('\nBLAD: '+str(error)+'\n')
        return False
    finally:
        if log:log.close()
