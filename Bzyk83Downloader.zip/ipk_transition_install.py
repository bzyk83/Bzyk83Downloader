#!/usr/bin/env python3
# -*- coding: ascii -*-
import sys
sys.path.insert(0,'/usr/lib/enigma2/python')
from Plugins.Extensions.Bzyk83Downloader.ipk_update import install
raise SystemExit(0 if install('https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/plugin.update.json') else 1)
