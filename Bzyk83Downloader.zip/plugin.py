# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, configfile
from enigma import eTimer, gRGB, eConsoleAppContainer
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from enigma import eDVBDB
import time
import urllib.request
import ssl
import zipfile
import os
import glob
import datetime
import threading
import subprocess
import json
import re
import io
import xml.etree.ElementTree as ET
try:
    from urllib.parse import urlencode, urljoin
    from http.cookiejar import CookieJar
except ImportError:
    from urllib import urlencode
    from urlparse import urljoin
    from cookielib import CookieJar

PLUGIN_VERSION_URL = "https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/plugin.version"
PLUGIN_ZIP_URL = "https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/Bzyk83Downloader.zip"
PLUGIN_VERSION_FILE = "/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader/plugin.version"
PLUGIN_TMP = "/tmp/bzyk83_plugin.zip"

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader"

GITHUB_BUKIETY_API = (
    "https://api.github.com/repos/bzyk83/listy/contents/bukiety"
)

BACKUP_DIR = "/etc/enigma2/Bzyk83Backup"
MAX_BACKUPS = 5

VERSION_FILE = "/etc/enigma2/userbouquet.version"
LAST_UPDATE_FILE = "/etc/enigma2/.bzyk83_last_update"
PATH_ZIP = "/tmp/lista_kanalow.zip"
EXTRACT_PATH = "/etc/enigma2/"

RAKUTEN_SCRIPT = "/usr/script/rakuten.py"
RAKUTEN_LOG = "/tmp/bzyk83_rakuten.log"
SWEET_SCRIPT = "/usr/script/sweet.py"
SWEET_LOG = "/tmp/bzyk83_sweet.log"
SWEET_BOUQUET = "/etc/enigma2/userbouquet.sweet.tv"
SWEET_CRON_MARKER = "/usr/script/sweet.py --refresh"
SWEET_INIT = "/etc/init.d/bzyk83-sweet-epg"
SWEET_LINK = "/etc/rc3.d/S98bzyk83-sweet-epg"

SATELLITES_PAGE = "http://satellites-xml.org/index.php"
SATELLITES_PATH = "/etc/tuxbox/satellites.xml"
SATELLITES_TMP_ZIP = "/tmp/bzyk83_satellites.zip"
SATELLITES_TMP_XML = "/tmp/bzyk83_satellites.xml"
SATELLITES_CAPTCHA = "/tmp/bzyk83_satellites_captcha.jpg"
SATELLITE_CHOICES = [
    ("5.0W Eutelsat 5 West B", "-50"),
    ("0.8W Thor / Intelsat", "-8"),
    ("4.8E Astra 4A / SES 5", "48"),
    ("9.0E Eutelsat 9B", "90"),
    ("13.0E Hotbird 13F/13G", "130"),
    ("16.0E Eutelsat 16A", "160"),
    ("19.2E Astra 1N/1P", "192"),
    ("23.5E Astra 3C", "235"),
    ("28.2E Astra 2E/2F/2G", "282")
]

LIST_URLS = {
    "hb": "https://raw.githubusercontent.com/bzyk83/listy/main/hb.zip",
    "dual": "https://raw.githubusercontent.com/bzyk83/listy/main/dual.zip",
    "3x1": "https://raw.githubusercontent.com/bzyk83/listy/main/3x1.zip",
    "4x1": "https://raw.githubusercontent.com/bzyk83/listy/main/4x1.zip",
    "5x1": "https://raw.githubusercontent.com/bzyk83/listy/main/5x1.zip",
    "6x1": "https://raw.githubusercontent.com/bzyk83/listy/main/6x1.zip",
    "8x1": "https://raw.githubusercontent.com/bzyk83/listy/main/8x1.zip"
}

VERSIONS_URL = "https://raw.githubusercontent.com/bzyk83/listy/main/versions.txt"

LIST_NAMES = {
    "hb": "HB 13E",
    "dual": "2x1 13E+19E",
    "3x1": "3x1 13E+19E+23E",
    "4x1": "4x1 13E+19E+23E+28E",
    "5x1": "5x1 13E+16E+19E+23E+28E",
    "6x1": "6x1 5E+13E+16E+19E+23E+28E",
    "8x1": "8x1 5W+08W+5E+13E+16E+19E+23E+28E"
}

def append_bzyk83_bouquet_name(path):
    """Dopisuje sygnature do nazwy bukietu bez modyfikowania referencji."""
    with open(path, "rb") as f:
        rows = f.readlines()
    if not rows or not rows[0].startswith(b"#NAME "):
        return
    name = rows[0].strip()
    if name.lower().endswith(b"(bzyk83)"):
        return
    rows[0] = name + b" (bzyk83)\n"
    tmp = path + ".bzyk83.tmp"
    try:
        with open(tmp, "wb") as f:
            f.writelines(rows)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

def get_list_name(list_type):
    return LIST_NAMES.get(list_type, list_type)

config.plugins.bzyk83_downloader = ConfigSubsection()
config.plugins.bzyk83_downloader.autostart = ConfigYesNo(default=True)
config.plugins.bzyk83_downloader.list_autoupdate = ConfigYesNo(default=False)
config.plugins.bzyk83_downloader.last_list_type = ConfigSelection(
    default="dual",
    choices=[
        ("hb", "Hotbird 13E"),
        ("dual", "2x1 13E+19E"),
        ("3x1", "3x1 13E+19E+23E"),
        ("4x1", "4x1 13E+19E+23E+28E"),
        ("5x1", "5x1 13E+16E+19E+23E+28E"),
        ("6x1", "6x1 5E+13E+16E+19E+23E+28E"),
        ("8x1", "8x1 5W+08W+5E+13E+16E+19E+23E+28E")
    ]
)

def get_local_list_version():
    try:
        if os.path.exists(VERSION_FILE):
            with open(VERSION_FILE, "r") as f:
                return f.read().strip()
    except:
        pass
    return "Brak"

def get_last_update():
    try:
        if os.path.exists(LAST_UPDATE_FILE):
            with open(LAST_UPDATE_FILE, "r") as f:
                return f.read().strip()
    except:
        pass
    return "Brak danych"

def get_remote_version(list_type):
    try:
        req = urllib.request.Request(VERSIONS_URL)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            data = r.read().decode("utf-8")

        versions = {}

        for line in data.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                versions[key.strip()] = value.strip()

        return versions.get(list_type, "")

    except:
        return ""
        
def get_remote_plugin_version():
    try:
        req = urllib.request.Request(PLUGIN_VERSION_URL)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            version = r.read().decode("utf-8").strip()

        print("[Bzyk83] REMOTE PLUGIN VERSION =", version)

        return version

    except Exception as e:
        print("[Bzyk83] get_remote_plugin_version:", e)
        return ""
        

def get_local_plugin_version():
    try:
        with open(PLUGIN_VERSION_FILE, "r") as f:
            return f.read().strip()
    except:
        return "Brak"        
        
def delete_old_bouquets():
    patterns = [
        "userbouquet.*.tv",
        "userbouquet.*.radio",
        "bouquets.tv",
        "bouquets.radio"
    ]

    for pattern in patterns:
        for f in glob.glob(os.path.join(EXTRACT_PATH, pattern)):
            try:
                os.remove(f)
            except:
                pass

def safe_extract(zip_ref, destination):

    base = os.path.abspath(destination)

    for member in zip_ref.namelist():

        target = os.path.abspath(
            os.path.join(destination, member)
        )

        if not target.startswith(base + os.sep):
            raise Exception(
                "Niebezpieczna ścieżka w archiwum: %s" % member
            )

    zip_ref.extractall(destination)

def cleanup_old_backups():

    if not os.path.exists(BACKUP_DIR):
        return

    backups = sorted(
        glob.glob(os.path.join(BACKUP_DIR, "backup_*.zip"))
    )

    while len(backups) > MAX_BACKUPS:
        try:
            os.remove(backups[0])
        except:
            pass

        backups.pop(0)

def create_backup():

    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    filename = time.strftime(
        "backup_%Y-%m-%d_%H-%M.zip"
    )

    backup_file = os.path.join(
        BACKUP_DIR,
        filename
    )

    with zipfile.ZipFile(
        backup_file,
        "w",
        zipfile.ZIP_DEFLATED,
        strict_timestamps=False
    ) as zipf:

        for fname in os.listdir("/etc/enigma2"):

            if (
                fname.startswith("userbouquet.")
                or fname in (
                    "bouquets.tv",
                    "bouquets.radio",
                    "lamedb",
                    "lamedb5"
                )
            ):

                full = os.path.join(
                    "/etc/enigma2",
                    fname
                )

                if os.path.isfile(full):
                    zipf.write(
                        full,
                        fname
                    )

    cleanup_old_backups()

    return backup_file
    
def reload_channel_database():
    def reload_now():
        db = eDVBDB.getInstance()
        db.reloadServicelist()
        db.reloadBouquets()

        from Screens.InfoBar import InfoBar
        infobar = InfoBar.instance
        if infobar is None:
            return

        csel = infobar.servicelist
        root = csel.getRoot()

        if root is None:
            csel.clearPath()
            csel.enterPath(csel.bouquet_root)
            return

        match = re.search(
            r'FROM BOUQUET "([^"]+)"', root.getPath()
        )
        if match and not os.path.isfile(
            os.path.join(EXTRACT_PATH, match.group(1))
        ):
            csel.clearPath()
            csel.enterPath(csel.bouquet_root)
        else:
            current = csel.getCurrentSelection()
            csel.setRoot(root)
            if current is not None:
                csel.setCurrentSelection(current)

    if threading.current_thread() is threading.main_thread():
        reload_now()
        return

    from twisted.internet import reactor
    completed = threading.Event()
    errors = []

    def finish():
        try:
            reload_now()
        except Exception as exc:
            errors.append(exc)
        finally:
            completed.set()

    reactor.callFromThread(finish)
    if not completed.wait(30):
        raise RuntimeError("Przekroczono czas przeładowania listy w Enigma2")
    if errors:
        raise errors[0]

def restore_backup(zip_path):

    with update_lock:

        if not os.path.exists(zip_path):
            raise Exception("Brak kopii")

        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            safe_extract(zip_ref, "/etc/enigma2")

        reload_channel_database()

def install_list(list_type):

    with update_lock:

        create_backup()

        url = LIST_URLS.get(list_type)

        if not url:
            raise Exception("Nieznany typ listy")

        try:
            if os.path.exists(PATH_ZIP):
                os.remove(PATH_ZIP)
        except:
            pass

        req = urllib.request.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=20) as response:
            with open(PATH_ZIP, "wb") as out:
                out.write(response.read())

        if not zipfile.is_zipfile(PATH_ZIP):
            raise Exception("Uszkodzony plik ZIP")

        preserved = {}
        for filename in ("userbouquet.sweet.tv", "userbouquet.rakuten.tv", "userbouquet.tvp_vod_free.tv"):
            target = os.path.join(EXTRACT_PATH, filename)
            if os.path.isfile(target):
                with open(target, "rb") as fp:
                    preserved[filename] = fp.read()

        delete_old_bouquets()

        with zipfile.ZipFile(PATH_ZIP, "r") as zip_ref:
            safe_extract(zip_ref, EXTRACT_PATH)

        for filename, data in preserved.items():
            target = os.path.join(EXTRACT_PATH, filename)
            with open(target, "wb") as fp:
                fp.write(data)
        index_path = os.path.join(EXTRACT_PATH, "bouquets.tv")
        with open(index_path, "a") as index:
            for filename in preserved:
                with open(index_path, "r") as check:
                    existing = check.read()
                if ('FROM BOUQUET "%s"' % filename) not in existing:
                    index.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % filename)
                    index.flush()

        try:
            os.remove(PATH_ZIP)
        except:
            pass

        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

        with open(LAST_UPDATE_FILE, "w") as f:
            f.write(now)

        reload_channel_database()
    
def update_plugin():

    with update_lock:

        try:

            req = urllib.request.Request(PLUGIN_ZIP_URL)
            req.add_header("User-Agent", "Mozilla/5.0")

            ctx = ssl.create_default_context()

            with urllib.request.urlopen(
                req,
                context=ctx,
                timeout=20
            ) as response:

                with open(PLUGIN_TMP, "wb") as out:
                    out.write(response.read())

            if not zipfile.is_zipfile(PLUGIN_TMP):
                raise Exception("Uszkodzony plik ZIP")

            with zipfile.ZipFile(PLUGIN_TMP, "r") as zip_ref:
                safe_extract(zip_ref, PLUGIN_PATH)

            return True

        except Exception as e:

            print("[Bzyk83] Plugin update error:", e)
            return False

        finally:

            try:
                if os.path.exists(PLUGIN_TMP):
                    os.remove(PLUGIN_TMP)
            except Exception as e:
                print("[Bzyk83] Cannot remove temp file:", e)
        
def open_bukiety_menu(self):

    try:
        req = urllib.request.Request(
            GITHUB_BUKIETY_API,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        data = json.loads(
            urllib.request.urlopen(req, timeout=15).read()
        )

        choices = []

        for item in data:

            if item["type"] == "file":

                choices.append(
                    (
                        item["name"],
                        item["download_url"]
                    )
                )

        choices.sort()

        self.session.openWithCallback(
            self.download_bouquet_selected,
            ChoiceBox,
            title="Wybierz bukiet",
            list=choices
        )

    except Exception as e:

        self.session.open(
            MessageBox,
            "Błąd pobierania listy bukietów:\n%s" % e,
            MessageBox.TYPE_ERROR
        )
        
def download_bouquet_selected(self, answer):

    if not answer:
        return

    name = answer[0]
    url = answer[1]

    self.download_github_bouquet(
        name,
        url
    )
    
def download_github_bouquet(self, name, url):

    try:

        target = "/etc/enigma2/" + name

        urllib.request.urlretrieve(
            url,
            target
        )
        append_bzyk83_bouquet_name(target)

        os.system(
            'wget -qO - "http://127.0.0.1/web/servicelistreload?mode=2" >/dev/null 2>&1'
        )

        self.session.open(
            MessageBox,
            "Bukiet pobrany:\n%s" % name,
            MessageBox.TYPE_INFO
        )

    except Exception as e:

        self.session.open(
            MessageBox,
            "Błąd:\n%s" % e,
            MessageBox.TYPE_ERROR
        )

def create_satellite_http_session():
    jar = CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    request = urllib.request.Request(SATELLITES_PAGE)
    request.add_header("User-Agent", "Mozilla/5.0")
    response = opener.open(request, timeout=20)
    html = response.read()
    if not isinstance(html, str):
        try:
            html = html.decode("latin-1")
        except:
            html = html.decode("utf-8", "ignore")
    match = re.search(r'<img[^>]+id=["\']captcha["\'][^>]+src=["\']([^"\']+)', html, re.I)
    if not match:
        match = re.search(r'<img[^>]+src=["\']([^"\']+)["\'][^>]+id=["\']captcha["\']', html, re.I)
    if not match:
        raise Exception("Nie znaleziono obrazka CAPTCHA na stronie")
    captcha_url = urljoin(SATELLITES_PAGE, match.group(1).replace("&amp;", "&"))
    req = urllib.request.Request(captcha_url)
    req.add_header("User-Agent", "Mozilla/5.0")
    req.add_header("Referer", SATELLITES_PAGE)
    data = opener.open(req, timeout=20).read()
    with open(SATELLITES_CAPTCHA, "wb") as f:
        f.write(data)
    return opener


def download_satellites_zip(opener, captcha, mode, selected):
    params = [
        ("search_type", mode),
        ("options[band]", "Ku"),
        ("options[transponders]", "all"),
        ("options[system]", "both"),
        ("options[encoding]", "UTF-8"),
        ("captcha", captcha),
        ("submit", "Download satellites.xml")
    ]
    if mode == "choose":
        if not selected:
            raise Exception("Nie wybrano żadnego satelity")
        for satellite_id in selected:
            params.append(("choose[]", satellite_id))
    url = SATELLITES_PAGE + "?" + urlencode(params)
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "Mozilla/5.0")
    req.add_header("Referer", SATELLITES_PAGE)
    response = opener.open(req, timeout=40)
    data = response.read()
    with open(SATELLITES_TMP_ZIP, "wb") as f:
        f.write(data)
    if not zipfile.is_zipfile(SATELLITES_TMP_ZIP):
        # Serwis może zwrócić HTML, np. błędny kod CAPTCHA.
        try:
            msg = data[:500].decode("utf-8", "ignore")
        except:
            msg = ""
        raise Exception("Serwis nie zwrócił ZIP. Sprawdź CAPTCHA. %s" % msg[:180])
    with zipfile.ZipFile(SATELLITES_TMP_ZIP, "r") as archive:
        candidates = [n for n in archive.namelist()
                      if os.path.basename(n).lower() == "satellites.xml"]
        if not candidates:
            raise Exception("W archiwum ZIP nie ma satellites.xml")
        info = archive.getinfo(candidates[0])
        if info.file_size <= 0 or info.file_size > 20 * 1024 * 1024:
            raise Exception("Nieprawidłowy rozmiar satellites.xml")
        xml_data = archive.read(candidates[0])
    with open(SATELLITES_TMP_XML, "wb") as f:
        f.write(xml_data)
    try:
        ET.parse(SATELLITES_TMP_XML)
    except Exception as e:
        raise Exception("Pobrany satellites.xml jest niepoprawny: %s" % e)
    target_dir = os.path.dirname(SATELLITES_PATH)
    if not os.path.isdir(target_dir):
        os.makedirs(target_dir)
    if os.path.exists(SATELLITES_PATH):
        backup = SATELLITES_PATH + ".bak"
        if os.path.exists(backup):
            backup = SATELLITES_PATH + ".%s.bak" % time.strftime("%Y%m%d-%H%M%S")
        import shutil
        shutil.copy2(SATELLITES_PATH, backup)
    
    import shutil
    target_tmp = SATELLITES_PATH + ".tmp"
    shutil.copyfile(SATELLITES_TMP_XML, target_tmp)
    ET.parse(target_tmp)
    os.rename(target_tmp, SATELLITES_PATH)
    try:
        os.remove(SATELLITES_TMP_XML)
    except:
        pass
    try:
        os.remove(SATELLITES_TMP_ZIP)
    except:
        pass
    try:
        os.remove(SATELLITES_CAPTCHA)
    except:
        pass
    return SATELLITES_PATH


class SatelliteSelectScreen(Screen):
    skin = """<screen position="center,center" size="850,560" title="Wybór satelitów">
        <widget name="list" position="20,20" size="810,450" scrollbarMode="showOnDemand" />
        <widget name="help" position="20,480" size="810,35" font="Regular;22" />
        <widget name="key_red" position="20,520" size="180,30" font="Regular;22" />
        <widget name="key_green" position="650,520" size="180,30" font="Regular;22" />
    </screen>"""
    def __init__(self, session, callback=None):
        Screen.__init__(self, session)
        from Components.MenuList import MenuList
        self.callback = callback
        self.selected = set(["-50", "-8", "48", "90", "130", "160", "192", "235", "282"])
        self["list"] = MenuList([])
        self["help"] = Label("OK - zaznacz/odznacz satelitę | ZIELONY - Dalej | CZERWONY - Wstecz")
        self["key_red"] = Label("Anuluj")
        self["key_green"] = Label("Dalej")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "WizardActions", "SetupActions"],
            {
                "ok": self.toggle,
                "cancel": self.go_back,
                "back": self.go_back,
                "red": self.go_back,
                "green": self.accept,
                "save": self.accept,
                "next": self.accept
            }, -2)
        self.onLayoutFinish.append(self.set_key_colors)
        self.refresh()

    def set_key_colors(self):
        try:
            self["key_green"].instance.setForegroundColor(gRGB(0x00CC00))
            self["key_red"].instance.setForegroundColor(gRGB(0xCC0000))
        except Exception:
            pass

    def refresh(self):
        rows = []
        for name, sid in SATELLITE_CHOICES:
            rows.append((("[X] " if sid in self.selected else "[ ] ") + name, sid))
        self["list"].setList(rows)

    def toggle(self):
        current = self["list"].getCurrent()
        if not current:
            return
        sid = current[1]
        if sid in self.selected:
            self.selected.remove(sid)
        else:
            self.selected.add(sid)
        self.refresh()

    def go_back(self):
        
        self.close(None)

    def accept(self):
        if not self.selected:
            self.session.open(MessageBox, "Zaznacz przynajmniej jednego satelitę.", MessageBox.TYPE_INFO)
            return
        self.close(sorted(list(self.selected), key=lambda x: int(x)))


class SatelliteCaptchaScreen(Screen):
    skin = """<screen position="center,center" size="700,440" title="CAPTCHA satellites-xml.org">
        <widget name="info" position="20,15" size="660,45" font="Regular;22" halign="center" />
        <widget name="captcha" position="190,75" size="320,110" />
        <widget name="code" position="100,220" size="500,50" font="Regular;30" halign="center" />
        <widget name="key_red" position="20,380" size="180,35" font="Regular;22" />
        <widget name="key_green" position="500,380" size="180,35" font="Regular;22" />
    </screen>"""
    def __init__(self, session, callback=None):
        Screen.__init__(self, session)
        from Components.Pixmap import Pixmap
        self.callback = callback
        self.code_value = ""
        self.picload = None
        self["info"] = Label("Przepisz kod z obrazka CAPTCHA")
        self["captcha"] = Pixmap()
        self["code"] = Label("Kod: naciśnij OK, aby wpisać")
        self["key_red"] = Label("Anuluj")
        self["key_green"] = Label("Wyślij")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "SetupActions"], {
            "ok": self.enter_code, "cancel": self.go_back, "back": self.go_back,
            "red": self.go_back, "green": self.submit
        }, -2)
        self.onLayoutFinish.append(self.load_image)
        self.onLayoutFinish.append(self.set_key_colors)

    def set_key_colors(self):
        try:
            self["key_green"].instance.setForegroundColor(gRGB(0x00CC00))
            self["key_red"].instance.setForegroundColor(gRGB(0xCC0000))
        except Exception:
            pass

    def load_image(self):
        try:
           
            from enigma import ePicLoad
            self.picload = ePicLoad()
            self.picload.PictureData.get().append(self.paint_image)
            size = self["captcha"].instance.size()
            try:
                self.picload.setPara((size.width(), size.height(), 1, 1, 0, 1, "#00000000"))
            except TypeError:
                self.picload.setPara((size.width(), size.height(), 1, 1, 0, 1, "#000000"))
            result = self.picload.startDecode(SATELLITES_CAPTCHA)
            if result not in (None, 0):
                self["info"].setText("Nie udało się zdekodować obrazka CAPTCHA (%s)" % result)
        except Exception as e:
            self["info"].setText("Błąd wyświetlania CAPTCHA: %s" % e)

    def paint_image(self, *args):
        try:
            ptr = self.picload.getData()
            if ptr:
                self["captcha"].instance.setPixmap(ptr)
            else:
                self["info"].setText("Nie udało się odczytać obrazka CAPTCHA")
        except Exception as e:
            self["info"].setText("Błąd obrazka CAPTCHA: %s" % e)

    def go_back(self):
        self.close(None)
    def enter_code(self):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        self.session.openWithCallback(self.code_entered, VirtualKeyBoard,
                                      title="Wpisz kod CAPTCHA", text=self.code_value)
    def code_entered(self, value):
        if value is not None:
            self.code_value = value.strip()
            self["code"].setText("Kod: " + self.code_value)
    def submit(self):
        if not self.code_value:
            self.enter_code()
            return
        self.close(self.code_value)


class DownloadListScreen(Screen):

    skin = """
    <screen position="center,center" size="1000,540" title="Bzyk83 Downloader">
        <widget name="status" position="20,20" size="960,50" font="Regular;30" halign="center"/>
        <widget name="info" position="20,90" size="960,40" font="Regular;24" halign="center"/>
        <widget name="update_info" position="20,140" size="960,40" font="Regular;24" halign="center"/>
        <widget name="last_update" position="20,190" size="960,40" font="Regular;24" halign="center"/>
        <widget name="plugin_version"
                position="20,240"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="plugin_update"
                position="20,280"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="autostart_status"
                position="20,320"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="key_red" position="20,420" size="220,50"
    backgroundColor="red"
    font="Regular;28"
    halign="center"
    valign="center"/>
        <widget name="key_green" position="260,420" size="220,50" backgroundColor="green"
    font="Regular;28" halign="center" valign="center"/>

        <widget name="key_yellow" position="500,420" size="220,50" backgroundColor="yellow"
    font="Regular;28" halign="center" valign="center"/>

        <widget name="key_blue" position="740,420" size="220,50" backgroundColor="blue"
    font="Regular;28" halign="center" valign="center"/>
  
        <widget name="key_menu"
                position="20,485"
                size="320,30"
                font="Regular;28"
                halign="left"
                valign="center"/>

  </screen>
    """
    
    def blue_action(self):

        if self.plugin_update_available:
            self.manual_plugin_update()
        else:
            self.toggle_autostart()

    def __init__(self, session):
        Screen.__init__(self, session)

        self["status"] = Label("Wtyczka gotowa")
        self["info"] = Label("")
        self["update_info"] = Label("")
        self["last_update"] = Label("")
        self["plugin_version"] = Label("")
        self["plugin_update"] = Label("")
        self["autostart_status"] = Label("")

        self["key_red"] = Label("Wyjście")
        self["key_green"] = Label("Wybór listy")
        self["key_yellow"] = Label("Pobierz")
        self["key_blue"] = Label("Autostart")
        self["key_menu"] = Label("")
    
                       
        self.plugin_update_available = False

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions", "MenuActions"],
            {
                "red": self.close,
                "green": self.select_list,
                "yellow": self.download_selected_list,
                "blue": self.blue_action,
                "menu": self.open_menu,
                "cancel": self.close
            },
            -1
        )

        self.onLayoutFinish.append(self.layoutFinished)
        
        self.guiTimer = eTimer()

        try:
            self.guiTimerConnection = self.guiTimer.timeout.connect(self.guiUpdate)
        except:
            self.guiTimer.callback.append(self.guiUpdate)

        self.sweet_process = None
        self.sweet_log_handle = None
        self.sweet_login_process = None
        self.sweet_login_buffer = ""
        self.sweet_login_code_shown = False
        self.rakuten_process = None
        self.rakuten_reload_process = None
        self.rakuten_pending_count = None
        self.rakuten_log_handle = None
        self.rakuten_worker_path = "/tmp/bzyk83_rakuten_reload_worker.py"

        self.guiAction = None
        self.download_running = False
        self.onClose.append(self.guiTimer.stop)

        self.satelliteTimer = eTimer()
        try:
            self.satelliteTimer.timeout.connect(self.satellite_gui_callback)
        except:
            self.satelliteTimer.callback.append(self.satellite_gui_callback)
        
    def guiUpdate(self):

        if self.guiAction is None:
            return
        self.guiTimer.stop()
        self.download_running = False
        if self.guiAction == "done":
            self.refresh_version_status()
            self.update_autostart_label()
            self["status"].setText("Gotowe.")

        elif self.guiAction and self.guiAction.startswith("error:"):
            self["status"].setText(
                self.guiAction[6:]
            )        

    def layoutFinished(self):
        self.refresh_version_status()
        self.update_autostart_label()
        self.update_backup_label()

        if self["key_menu"].instance:
            self["key_menu"].instance.setForegroundColor(
                gRGB(0x66CCFF))
           
                        
    def refresh_version_status(self):

        list_type = config.plugins.bzyk83_downloader.last_list_type.value

        mode_name = LIST_NAMES.get(list_type, list_type)

        local_version = get_local_list_version()
        remote_version = get_remote_version(list_type)

        local_plugin = get_local_plugin_version()
        remote_plugin = get_remote_plugin_version()

        self["status"].setText(
            "Aktywna lista: %s" % mode_name
        )

        self["info"].setText(
            "Wersja zainstalowana: %s" % local_version
        )

        if not remote_version:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0xFF0000)
                )

            txt = "brak połączenia"

        elif local_version == remote_version:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0xFFFFFF)
                )

            txt = "aktualna (%s)" % remote_version

        else:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0x00FF00)
                )

            txt = "NOWA (%s)" % remote_version

        self["update_info"].setText(
            "Dostępna aktualizacja: %s" % txt
        )

        self["last_update"].setText(
            "Ostatnia aktualizacja: %s" % get_last_update()
        )

        self["plugin_version"].setText(
            "Wersja wtyczki: %s" % local_plugin
        )

        if not remote_plugin:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0xFF0000)
                )

            self["plugin_update"].setText(
                "Aktualizacja wtyczki: brak połączenia"
            )

            self.plugin_update_available = False
            self["key_blue"].setText("Autostart")

        elif remote_plugin == local_plugin:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0xFFFFFF)
                )

            self["plugin_update"].setText(
                "Aktualizacja wtyczki: aktualna (%s)" % remote_plugin
            )

            self.plugin_update_available = False
            self["key_blue"].setText("Autostart")

        else:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0x00FF00)
                )

            self["plugin_update"].setText(
                "Dostępna aktualizacja: %s" % remote_plugin
            )

            self.plugin_update_available = True
            self["key_blue"].setText("Aktualizuj")


    def open_menu(self):

        count = len(
            glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            )
        )

        menu = [
            ("Kopie zapasowe (%d)" % count, "backup"),
            ("Dodatkowe bukiety", "bouquets"),
            ("Rakuten TV Polska", "rakuten"),
            ("SWEET.TV Polska", "sweet"),
            ("Kamery internetowe (soon)", "cameras"),
            ("Reset hasła do tunera", "password"),
            ("Aktualizacja satellites.xml", "satellites")
        ]

        self.session.openWithCallback(
            self.menuCallback,
            ChoiceBox,
            title="Wybierz opcję",
            list=menu
        )
        
    def menuCallback(self, answer):

        if not answer:
            return

        action = answer[1]

        if action == "backup":

            self.session.openWithCallback(
                self.backupMenuCallback,
                ChoiceBox,
                title="- dodatki",
                list=[
                    ("Utwórz kopię list", "backup"),
                    ("Przywróć kopię", "restore"),
                    ("Usuń wszystkie kopie", "delete")
                ]
            )

        elif action == "bouquets":
            self.open_bukiety_menu()

        elif action == "rakuten":
            self.show_rakuten_menu()

        elif action == "sweet":
            self.show_sweet_menu()

        elif action == "cameras":
            self.showCameraMenu()

        elif action == "satellites":
            self.show_satellites_menu()

        elif action == "password":
            self.show_password_menu()

    def sweet_channel_count(self):
        try:
            with open(SWEET_BOUQUET, "r") as f:
                return sum(1 for line in f if line.startswith("#SERVICE 4097:"))
        except IOError:
            return 0

    def sweet_cron_enabled(self):
        try:
            output = subprocess.check_output(["crontab", "-l"], stderr=subprocess.DEVNULL)
            return SWEET_CRON_MARKER in output.decode("utf-8", "replace")
        except Exception:
            return False

    def sweet_epg_server(self):
        try:
            import urllib.request
            with urllib.request.urlopen("http://127.0.0.1:8765/sweet_epg.xml", timeout=2) as r:
                return r.status == 200
        except Exception:
            return False

    def sweet_epg_autostart(self):
        return os.path.islink(SWEET_LINK)

    def sweet_toggle_epg_autostart(self):
        try:
            if self.sweet_epg_autostart():
                os.unlink(SWEET_LINK)
                self.session.open(MessageBox, "Autostart EPG wyłączony. Działający serwer pozostaje uruchomiony.", MessageBox.TYPE_INFO)
                return
            if not os.path.isfile(SWEET_INIT):
                self.session.open(MessageBox, "Najpierw wgraj plik bzyk83-sweet-epg do /etc/init.d/ i ustaw chmod +x.", MessageBox.TYPE_ERROR)
                return
            if not os.path.isdir(os.path.dirname(SWEET_LINK)):
                self.session.open(MessageBox, "Brak /etc/rc3.d — sprawdź system init dekodera.", MessageBox.TYPE_ERROR)
                return
            os.symlink(SWEET_INIT, SWEET_LINK)
            if not self.sweet_epg_server():
                subprocess.check_call([SWEET_INIT, "start"])
            self.session.open(MessageBox, "Autostart serwera EPG włączony. Stan: %s" % ("DZIAŁA" if self.sweet_epg_server() else "Sprawdź /tmp/bzyk83_sweet_http.log"), MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Błąd serwera EPG: %s" % e, MessageBox.TYPE_ERROR)

    def show_sweet_menu(self):
        enabled = self.sweet_cron_enabled()
        self.session.openWithCallback(
            self.sweet_menu_callback, ChoiceBox, title="SWEET.TV Polska",
            list=[
                ("Aktualizuj kanały i EPG", "update"),
                ("Automatyczne odświeżanie: %s" % ("WŁ" if enabled else "WYŁ"), "cron"),
                ("Autostart serwera EPG: %s" % ("WŁ" if self.sweet_epg_autostart() else "WYŁ"), "epgserver"),
                ("Status SWEET.TV", "status"),
                ("Pokaż ostatni wynik", "log"),
                ("Logowanie SWEET.TV (kod na ekranie)", "login")
            ])

    def sweet_menu_callback(self, answer):
        if not answer:
            return
        action = answer[1]
        if action == "update":
            self.session.openWithCallback(
                self.sweet_confirmed, MessageBox,
                "Odświeżyć kanały HLS i EPG SWEET.TV?\n"
                "Zostaną użyte referencje z istniejącego sweet.py.",
                MessageBox.TYPE_YESNO, default=False)
        elif action == "cron":
            self.sweet_toggle_cron()
        elif action == "epgserver":
            self.sweet_toggle_epg_autostart()
        elif action == "status":
            self.sweet_show_status()
        elif action == "log":
            self.sweet_show_log()
        elif action == "login":
            self.sweet_start_login()

    def sweet_start_login(self):
        if self.sweet_login_process is not None or self.sweet_process is not None:
            self.session.open(MessageBox, "Operacja SWEET.TV już trwa.", MessageBox.TYPE_INFO)
            return
        if not os.path.isfile(SWEET_SCRIPT):
            self.session.open(MessageBox, "Brak skryptu: %s" % SWEET_SCRIPT, MessageBox.TYPE_ERROR)
            return
        try:
            self.sweet_login_buffer = ""
            self.sweet_login_code_shown = False
            container = eConsoleAppContainer()
            self.sweet_login_process = container
            self.rakuten_connect_event(container.dataAvail, self.sweet_login_output)
            self.rakuten_connect_event(container.appClosed, self.sweet_login_closed)
            ret = container.execute("/usr/bin/python3", "python3", "-u", SWEET_SCRIPT, "--login")
            if ret:
                raise RuntimeError("Nie można uruchomić logowania (kod %s)" % ret)
            self["status"].setText("SWEET.TV: pobieranie kodu logowania...")
        except Exception as e:
            self.sweet_login_process = None
            self.session.open(MessageBox, "Błąd logowania: %s" % e, MessageBox.TYPE_ERROR)

    def sweet_login_output(self, data):
        if isinstance(data, bytes):
            data = data.decode("utf-8", "replace")
        self.sweet_login_buffer = (self.sweet_login_buffer + data)[-6000:]
        if not self.sweet_login_code_shown:
            match = re.search(r"WPISZ KOD:\s*([A-Za-z0-9-]+)", self.sweet_login_buffer)
            if match:
                self.sweet_login_code_shown = True
                code = match.group(1)
                self["status"].setText("SWEET.TV: kod logowania %s" % code)
                self.session.open(
                    MessageBox,
                    "KOD LOGOWANIA SWEET.TV\n\n%s\n\n"
                    "Wpisz w przeglądarce:\nhttps://sweet.tv/pl-pl/cabinet/devices\n\n"
                    "Wpisz kod i zatwierdź.\n"
                    "Oczekiwanie na logowanie trwa do 5 minut."
                    % code,
                    MessageBox.TYPE_INFO, timeout=0)

    def sweet_login_closed(self, result):
        self.sweet_login_process = None
        if result == 0:
            self["status"].setText("SWEET.TV: zalogowano pomyślnie")
            self.session.open(MessageBox,
                "SWEET.TV: logowanie zakończone pomyślnie.\n"
                "Możesz teraz zaktualizować kanały i EPG.",
                MessageBox.TYPE_INFO)
        else:
            
            lines = [x.strip() for x in self.sweet_login_buffer.splitlines() if x.strip()]
            detail = lines[-1] if lines else "Brak odpowiedzi skryptu."
            self["status"].setText("SWEET.TV: logowanie nieudane")
            self.session.open(MessageBox,
                "Logowanie SWEET.TV nie powiodło się (kod %s).\n%s" %
                (result, detail[:250]), MessageBox.TYPE_ERROR)

    def sweet_show_status(self):
        installed = os.path.isfile(SWEET_SCRIPT)
        count = self.sweet_channel_count()
        cron = self.sweet_cron_enabled()
        epg = "/etc/enigma2/sweet_epg.xml"
        auth = "/etc/enigma2/sweet_auth.json"
        epg_count = 0
        epg_time = "brak danych"
        if os.path.isfile(epg):
            try:
                
                with open(epg, "rb") as f:
                    epg_count = f.read().count(b"<programme ")
                epg_time = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(epg)))
            except Exception:
                pass
        bouquet_time = "brak danych"
        if os.path.isfile(SWEET_BOUQUET):
            try:
                bouquet_time = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(SWEET_BOUQUET)))
            except Exception:
                pass
        msg = ("SWEET.TV Polska\n\n"
               "Skrypt: %s\n"
               "Dane logowania: %s\n"
               "Kanały w bukiecie: %d\n"
               "Audycje EPG: %d\n"
               "Aktualizacja bukietu: %s\n"
               "Aktualizacja EPG: %s\n"
               "Odświeżanie co 6 godzin: %s\n"
               "Serwer EPG: %s\n"
               "Autostart serwera: %s" %
               ("zainstalowany" if installed else "BRAK",
                "zapisane" if os.path.isfile(auth) else "brak",
                count, epg_count, bouquet_time, epg_time,
                "WŁ" if cron else "WYŁ",
                "DZIAŁA" if self.sweet_epg_server() else "NIE DZIAŁA",
                "WŁ" if self.sweet_epg_autostart() else "WYŁ"))
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)

    def sweet_show_log(self):
        try:
            with open(SWEET_LOG, "rb") as f:
                content = f.read()[-7000:].decode("utf-8", "replace")
            lines = [line.strip() for line in content.splitlines() if line.strip()]
            message = "\n".join(lines[-14:]) or "Log jest pusty."
        except IOError:
            message = "Brak logu aktualizacji SWEET.TV."
        self.session.open(MessageBox, message[-1500:], MessageBox.TYPE_INFO)

    def sweet_toggle_cron(self):
        if not os.path.isfile(SWEET_SCRIPT):
            self.session.open(MessageBox, "Brak /usr/script/sweet.py", MessageBox.TYPE_ERROR)
            return
        enabled = self.sweet_cron_enabled()
        try:
            command = ["/usr/bin/python3", SWEET_SCRIPT,
                       "--remove-cron" if enabled else "--install-cron"]
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError((err or out).decode("utf-8", "replace")[-400:])
            self.session.open(MessageBox,
                "Automatyczne odświeżanie SWEET.TV: %s" % ("WYŁ" if enabled else "WŁ"),
                MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Błąd harmonogramu: %s" % e, MessageBox.TYPE_ERROR)

    def sweet_confirmed(self, confirmed):
        if not confirmed:
            return
        if self.sweet_process is not None:
            self.session.open(MessageBox, "Aktualizacja SWEET.TV już trwa.", MessageBox.TYPE_INFO)
            return
        if not os.path.isfile(SWEET_SCRIPT):
            self.session.open(MessageBox, "Brak skryptu: %s" % SWEET_SCRIPT, MessageBox.TYPE_ERROR)
            return
        try:
            self.sweet_log_handle = open(SWEET_LOG, "wb")
            container = eConsoleAppContainer()
            self.sweet_process = container
            self.rakuten_connect_event(container.dataAvail, self.sweet_output)
            self.rakuten_connect_event(container.appClosed, self.sweet_closed)
            ret = container.execute("/usr/bin/python3", "python3", "-u", SWEET_SCRIPT, "--refresh")
            if ret:
                raise RuntimeError("Nie udało się uruchomić sweet.py (kod %s)" % ret)
            self["status"].setText("SWEET.TV: trwa odświeżanie...")
            self.session.open(MessageBox, "Rozpoczęto aktualizację SWEET.TV w tle.",
                              MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.sweet_process = None
            if self.sweet_log_handle:
                self.sweet_log_handle.close()
                self.sweet_log_handle = None
            self.session.open(MessageBox, "Błąd SWEET.TV: %s" % e, MessageBox.TYPE_ERROR)

    def sweet_output(self, data):
        try:
            if isinstance(data, str):
                data = data.encode("utf-8", "replace")
            if self.sweet_log_handle:
                self.sweet_log_handle.write(data)
                self.sweet_log_handle.flush()
        except Exception as e:
            print("[Bzyk83] SWEET log error:", e)

    def sweet_closed(self, result):
        self.sweet_process = None
        if self.sweet_log_handle:
            self.sweet_log_handle.close()
            self.sweet_log_handle = None
        count = self.sweet_channel_count()
        if result == 0 and count > 0:
            try:
                append_bzyk83_bouquet_name(SWEET_BOUQUET)
            except Exception as exc:
                print("[Bzyk83] SWEET bouquet name:", exc)
            self["status"].setText("SWEET.TV: zaktualizowano %d kanałów" % count)
            self.session.open(MessageBox,
                "SWEET.TV: odświeżono %d kanałów.\n"
                "EPG zapisano do importu EPGImport." % count,
                MessageBox.TYPE_INFO, timeout=8)
        else:
            self["status"].setText("SWEET.TV: błąd aktualizacji")
            self.sweet_show_log()

    def show_rakuten_menu(self):
        self.session.openWithCallback(
            self.rakuten_menu_callback,
            ChoiceBox,
            title="Rakuten TV Polska",
            list=[
                ("Aktualizuj kanały Rakuten TV PL", "update"),
                ("Pokaż ostatni wynik aktualizacji", "log")
            ]
        )

    def rakuten_menu_callback(self, answer):
        if not answer:
            return
        if answer[1] == "log":
            self.rakuten_show_log()
        elif answer[1] == "update":
            self.session.openWithCallback(
                self.rakuten_confirmed,
                MessageBox,
                "Zaktualizować kanały Rakuten TV Polska?\\n"
                "Istniejący skrypt zachowa swoje referencje EPG.",
                MessageBox.TYPE_YESNO,
                default=False
            )

    def rakuten_event_log(self, message):
        try:
            with open("/tmp/bzyk83_rakuten_events.log", "a") as f:
                f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), message))
        except Exception:
            pass

    def rakuten_connect_event(self, event, callback):
        
        try:
            event.get().append(callback)
        except AttributeError:
            event.append(callback)

    def rakuten_output(self, data):
        try:
            if isinstance(data, str):
                data = data.encode("utf-8", "replace")
            with open(RAKUTEN_LOG, "ab") as f:
                f.write(data)
        except Exception as e:
            self.rakuten_event_log("blad zapisu logu: %s" % e)

    def rakuten_confirmed(self, confirmed):
        if not confirmed:
            return
        if self.rakuten_process is not None or self.rakuten_reload_process is not None:
            self.session.open(MessageBox, "Aktualizacja Rakuten TV już trwa.",
                              MessageBox.TYPE_INFO, timeout=5)
            return
        if not os.path.isfile(RAKUTEN_SCRIPT):
            self.session.open(MessageBox, "Brak skryptu: %s" % RAKUTEN_SCRIPT,
                              MessageBox.TYPE_ERROR)
            return
        try:
            with open(RAKUTEN_LOG, "wb") as f:
                pass
            with open("/tmp/bzyk83_rakuten_events.log", "w") as f:
                f.write("START\n")
            container = eConsoleAppContainer()
            self.rakuten_process = container
            self.rakuten_connect_event(container.dataAvail, self.rakuten_output)
            self.rakuten_connect_event(container.appClosed, self.rakuten_script_closed)
            ret = container.execute("python3", "python3", "-u", RAKUTEN_SCRIPT)
            if ret:
                raise RuntimeError("Nie mozna uruchomic python3 (kod %s)" % ret)
            self.rakuten_event_log("uruchomiono rakuten.py")
            self["status"].setText("Aktualizacja Rakuten TV PL w toku...")
            self.session.open(MessageBox,
                "Uruchomiono aktualizację Rakuten TV PL.\nWynik pojawi się po zakończeniu.",
                MessageBox.TYPE_INFO, timeout=5)
        except Exception as e:
            self.rakuten_process = None
            self.rakuten_event_log("blad startu: %s" % e)
            self.session.open(MessageBox, "Nie można uruchomić Rakuten: %s" % e,
                              MessageBox.TYPE_ERROR)

    def rakuten_script_closed(self, result):
        self.rakuten_event_log("rakuten.py appClosed kod=%s" % result)
        self.rakuten_process = None
        count = self.rakuten_count_from_log()
        if result != 0 or count is None or count <= 0:
            self["status"].setText("Rakuten PL: aktualizacja nieudana")
            self.rakuten_show_log(exit_code=result if result != 0 else 1)
            return
        try:
            self.rakuten_set_bouquet_name()
            
            reload_code = (
                "import os, subprocess, time, sys, xml.etree.ElementTree as ET\n"
                "log = open('/tmp/bzyk83_rakuten_reload.log', 'w', 1)\n"
                "log.write('reload worker started\\n')\n"
                "success = False\n"
                "for attempt, delay in enumerate((3, 12, 20), 1):\n"
                "    time.sleep(delay)\n"
                "    try:\n"
                "        bouquet = '/etc/enigma2/userbouquet.rakuten.tv'\n"
                "        index = '/etc/enigma2/bouquets.tv'\n"
                "        exists = os.path.isfile(bouquet) and os.path.getsize(bouquet) > 0\n"
                "        linked = os.path.isfile(index) and b'userbouquet.rakuten.tv' in open(index, 'rb').read()\n"
                "        p = subprocess.Popen(['wget', '-T', '10', '-qO', '-', 'http://127.0.0.1/web/servicelistreload?mode=0'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)\n"
                "        out, err = p.communicate()\n"
                "        state = ET.fromstring(out).findtext('e2state') if p.returncode == 0 else None\n"
                "        log.write('attempt=%d delay=%ds exit=%s state=%s bouquet=%s linked=%s\\n' % (attempt, delay, p.returncode, state, exists, linked))\n"
                "        success = success or (state == 'True' and exists and linked)\n"
                "    except Exception as e:\n"
                "        log.write('attempt=%d error=%s\\n' % (attempt, e))\n"
                "log.close()\n"
                "sys.exit(0 if success else 1)\n"
            )
            with open(self.rakuten_worker_path, "w") as f:
                f.write(reload_code)
            self.rakuten_pending_count = count
            container = eConsoleAppContainer()
            self.rakuten_reload_process = container
            self.rakuten_connect_event(container.dataAvail, self.rakuten_reload_output)
            self.rakuten_connect_event(container.appClosed, self.rakuten_reload_closed)
            ret = container.execute("python3", "python3", "-u", self.rakuten_worker_path)
            if ret:
                raise RuntimeError("Nie mozna uruchomic procesu reload (kod %s)" % ret)
            self.rakuten_event_log("uruchomiono reload, kanalow=%d" % count)
            self["status"].setText("Rakuten PL: odświeżanie bukietów...")
        except Exception as e:
            self.rakuten_reload_process = None
            self.rakuten_event_log("blad reload: %s" % e)
            self["status"].setText("Rakuten PL: błąd przeładowania list")
            self.session.open(MessageBox,
                "Pobrano %d kanałów, ale nie udało się uruchomić odświeżania: %s" % (count, e),
                MessageBox.TYPE_ERROR)

    def rakuten_reload_output(self, data):
        try:
            if isinstance(data, bytes):
                data = data.decode("utf-8", "replace")
            self.rakuten_event_log("reload stdout/stderr: %s" % data.strip())
        except Exception:
            pass

    def rakuten_reload_closed(self, result):
        self.rakuten_event_log("reload appClosed kod=%s" % result)
        self.rakuten_reload_process = None
        count = self.rakuten_pending_count
        self.rakuten_pending_count = None
        if count is None:
            self.rakuten_event_log("brak liczby kanalow")
            return
        if result == 0:
            self["status"].setText("Rakuten PL: pobrano %d kanałów" % count)
            self.session.open(MessageBox, "Pobrano %d kanałów" % count,
                              MessageBox.TYPE_INFO, timeout=8)
        else:
            self["status"].setText("Rakuten PL: błąd odświeżania")
            self.session.open(MessageBox,
                "Pobrano %d kanałów, ale nie potwierdzono przeładowania list." % count,
                MessageBox.TYPE_ERROR)

    def rakuten_count_from_log(self):
        try:
            with open(RAKUTEN_LOG, "rb") as f:
                data = f.read().decode("utf-8", "replace")
            
            patterns = [r"Aktywne kanały\s*:\s*(\d+)",
                        r"Kanaly pobrane\s*:\s*(\d+)",
                        r"Kanały pobrane\s*:\s*(\d+)"]
            for pattern in patterns:
                matches = re.findall(pattern, data, re.I)
                if matches:
                    return int(matches[-1])
        except Exception:
            pass
        return None

    def rakuten_set_bouquet_name(self):
        target = "/etc/enigma2/userbouquet.rakuten.tv"
        if not os.path.isfile(target):
            raise IOError("Brak bukietu %s" % target)
        with open(target, "rb") as f:
            content = f.read()
        lines = content.splitlines(True)
        if not lines or not lines[0].startswith(b"#NAME "):
            raise ValueError("Brak nagłówka #NAME w bukiecie Rakuten")
        if lines[0] != b"#NAME Rakuten PL (bzyk83)\n":
            lines[0] = b"#NAME Rakuten PL (bzyk83)\n"
            tmp = target + ".bzyk83.tmp"
            try:
                with open(tmp, "wb") as f:
                    f.write(b"".join(lines))
                os.rename(tmp, target)
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)

    def rakuten_show_log(self, exit_code=None):
        count = self.rakuten_count_from_log()
        if count is not None and count > 0 and exit_code in (None, 0):
            message = "Pobrano %d kanałów" % count
            mtype = MessageBox.TYPE_INFO
        elif count == 0:
            message = "Nie pobrano żadnych kanałów."
            mtype = MessageBox.TYPE_ERROR
        else:
            message = "Nie udało się potwierdzić liczby pobranych kanałów."
            mtype = MessageBox.TYPE_ERROR
        if exit_code not in (None, 0):
            message = "Aktualizacja nieudana (kod %s).\n%s" % (exit_code, message)
            mtype = MessageBox.TYPE_ERROR
        self.session.open(MessageBox, message, mtype)

    def show_password_menu(self):
        self.session.openWithCallback(
            self.password_mode_callback,
            ChoiceBox,
            title="Reset hasła użytkownika root",
            list=[
                ("Usuń hasło (logowanie bez hasła)", "empty"),
                ("Ustaw nowe hasło", "new")
            ]
        )

    def password_mode_callback(self, answer):
        if not answer:
            return
        if answer[1] == "empty":
            self.session.openWithCallback(
                self.clear_password_confirmed,
                MessageBox,
                "UWAGA! Usunięcie hasła root umożliwi logowanie bez hasła i jest niebezpieczne. Kontynuować?",
                type=MessageBox.TYPE_YESNO,
                default=False,
                timeout=0
            )
        elif answer[1] == "new":
            self.ask_new_root_password()

    def clear_password_confirmed(self, confirmed):
        if not confirmed:
            return
        passwd_bin = None
        for candidate in ("/usr/bin/passwd", "/bin/passwd", "/usr/sbin/passwd", "/sbin/passwd"):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                passwd_bin = candidate
                break
        if not passwd_bin:
            self.session.open(
                MessageBox,
                "Nie znaleziono polecenia passwd. Hasło nie zostało zmienione.",
                type=MessageBox.TYPE_ERROR,
                timeout=6
            )
            return
        try:
            proc = subprocess.Popen(
                [passwd_bin, "-d", "root"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            output, error = proc.communicate()
            if proc.returncode == 0:
                msg = "Hasło użytkownika root zostało usunięte. Logowanie może być teraz możliwe bez hasła."
                mtype = MessageBox.TYPE_INFO
            else:
                detail = error or output or "brak szczegółów"
                if not isinstance(detail, str):
                    detail = detail.decode("utf-8", "ignore")
                msg = "Nie udało się usunąć hasła root: %s" % detail
                mtype = MessageBox.TYPE_ERROR
        except Exception as e:
            msg = "Błąd podczas zmiany hasła: %s" % e
            mtype = MessageBox.TYPE_ERROR
        self.session.open(MessageBox, msg, type=mtype, timeout=8)

    def ask_new_root_password(self):
        try:
            from Screens.InputBox import InputBox
            from Components.Input import Input
            self.session.openWithCallback(
                self.new_root_password_entered,
                InputBox,
                title="Wpisz nowe hasło dla root (tekst będzie widoczny)",
                text="",
                maxSize=False,
                type=Input.TEXT
            )
        except Exception as e:
            self.session.open(
                MessageBox,
                "Nie można otworzyć pola hasła: %s" % e,
                type=MessageBox.TYPE_ERROR,
                timeout=6
            )

    def new_root_password_entered(self, password):
        if password is None:
            return
        if not password or ":" in password or "\n" in password or "\r" in password:
            self.session.open(
                MessageBox,
                "Hasło może mieć dowolną długość, ale nie może być puste ani zawierać dwukropka lub znaków nowej linii.",
                type=MessageBox.TYPE_ERROR,
                timeout=7
            )
            return
        self.pending_root_password = password
        self.confirm_new_root_password()

    def confirm_new_root_password(self):
        try:
            from Screens.InputBox import InputBox
            from Components.Input import Input
            self.session.openWithCallback(
                self.confirm_root_password_entered,
                InputBox,
                title="Powtórz nowe hasło dla root (tekst będzie widoczny)",
                text="",
                maxSize=False,
                type=Input.TEXT
            )
        except Exception as e:
            self.pending_root_password = None
            self.session.open(
                MessageBox,
                "Nie można otworzyć potwierdzenia hasła: %s" % e,
                type=MessageBox.TYPE_ERROR,
                timeout=6
            )

    def confirm_root_password_entered(self, confirmation):
        password = getattr(self, "pending_root_password", None)
        self.pending_root_password = None
        if confirmation is None:
            return
        if password is None or confirmation != password:
            self.session.open(
                MessageBox,
                "Wpisane hasła nie są identyczne. Hasło nie zostało zmienione.",
                type=MessageBox.TYPE_ERROR,
                timeout=6
            )
            return
        chpasswd_bin = None
        for candidate in ("/usr/sbin/chpasswd", "/sbin/chpasswd", "/usr/bin/chpasswd", "/bin/chpasswd"):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                chpasswd_bin = candidate
                break
        if not chpasswd_bin:
            self.session.open(
                MessageBox,
                "System nie udostępnia polecenia chpasswd. Hasło nie zostało zmienione.",
                type=MessageBox.TYPE_ERROR,
                timeout=7
            )
            return
        try:
            proc = subprocess.Popen(
                [chpasswd_bin],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            payload = "root:%s\n" % password
            if not isinstance(payload, bytes):
                payload = payload.encode("utf-8")
            output, error = proc.communicate(payload)
            if proc.returncode == 0:
                msg = "Nowe hasło użytkownika root zostało ustawione."
                mtype = MessageBox.TYPE_INFO
            else:
                detail = error or output or "brak szczegółów"
                if not isinstance(detail, str):
                    detail = detail.decode("utf-8", "ignore")
                msg = "Nie udało się ustawić hasła root: %s" % detail
                mtype = MessageBox.TYPE_ERROR
        except Exception as e:
            msg = "Błąd podczas zmiany hasła: %s" % e
            mtype = MessageBox.TYPE_ERROR
        password = None
        self.session.open(MessageBox, msg, type=mtype, timeout=8)

    def show_satellites_menu(self):
        self.session.openWithCallback(
            self.satellites_mode_callback,
            ChoiceBox,
            title="Aktualizacja satellites.xml",
            list=[("Wybierz satelity", "choose"),
                  ("Pobierz pełny plik (wszystkie satelity)", "all")]
        )

    def satellites_mode_callback(self, answer):
        if not answer:
            return
        mode = answer[1]
        if mode == "choose":
            self.session.openWithCallback(
                self.satellites_selected_callback, SatelliteSelectScreen, self
            )
        else:
            self.prepare_satellites_update("all", [])

    def satellites_selected_callback(self, selected):
        if selected is None:
            
            self.show_satellites_menu()
        elif selected:
            self.prepare_satellites_update("choose", selected)

    def prepare_satellites_update(self, mode, selected):
        self["status"].setText("Pobieranie formularza i CAPTCHA...")
        self.satellite_mode = mode
        self.satellite_selected = selected
        self.satellite_opener = None
        self.satellite_result = None
        def worker():
            try:
                self.satellite_opener = create_satellite_http_session()
                self.satellite_result = "ready"
            except Exception as e:
                self.satellite_result = "error:%s" % e
            self.satelliteTimer.start(100, True)
        threading.Thread(target=worker, daemon=True).start()

    def satellite_gui_callback(self):
        result = self.satellite_result
        if not result:
            return
        if result.startswith("error:"):
            self["status"].setText("Błąd CAPTCHA: %s" % result[6:])
            self.session.open(MessageBox, result[6:], MessageBox.TYPE_ERROR)
            return
        if result == "ready":
            self["status"].setText("Oczekiwanie na kod CAPTCHA...")
            self.session.openWithCallback(
                self.satellite_captcha_callback, SatelliteCaptchaScreen
            )
        elif result == "done":
            self["status"].setText("Zaktualizowano satellites.xml")
            self.session.openWithCallback(
                self.satellites_restart_callback,
                MessageBox,
                "Plik satellites.xml został zaktualizowany.\n\n"
                "Aby wprowadzić zmiany, należy ponownie uruchomić GUI Enigma2.\n\n"
                "Czy uruchomić GUI ponownie teraz?",
                MessageBox.TYPE_YESNO,
                default=True
            )
        elif result.startswith("error_install:"):
            self["status"].setText("Błąd aktualizacji satellites.xml")
            self.session.open(MessageBox, result[14:], MessageBox.TYPE_ERROR)

    def satellites_restart_callback(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)

    def satellite_captcha_callback(self, code):
        if not code:
            self["status"].setText("Anulowano aktualizację satellites.xml")
            return
        self["status"].setText("Pobieranie i sprawdzanie satellites.xml...")
        def worker():
            try:
                with update_lock:
                    download_satellites_zip(self.satellite_opener, code,
                                            self.satellite_mode, self.satellite_selected)
                self.satellite_result = "done"
            except Exception as e:
                self.satellite_result = "error_install:%s" % e
            self.satelliteTimer.start(100, True)
        threading.Thread(target=worker, daemon=True).start()

    def backupMenuCallback(self, answer):

        if not answer:
            return

        action = answer[1]

        if action == "backup":

            try:
                path = create_backup()

                self.update_backup_label()

                self.session.open(
                    MessageBox,
                    "Kopia utworzona:\n%s" %
                    os.path.basename(path),
                    MessageBox.TYPE_INFO
                )

            except Exception as e:

                self.session.open(
                    MessageBox,
                    str(e),
                    MessageBox.TYPE_ERROR
                )

        elif action == "restore":

            self.show_backup_list()

        elif action == "delete":

            count = 0

            for f in glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            ):
                try:
                    os.remove(f)
                    count += 1
                except:
                    pass

            self.update_backup_label()

            self.session.open(
                MessageBox,
                "Usunięto %d kopii." % count,
                MessageBox.TYPE_INFO
            ) 

    def update_autostart_label(self):
        enabled = config.plugins.bzyk83_downloader.autostart.value
        mode = config.plugins.bzyk83_downloader.last_list_type.value

        mode_name = LIST_NAMES.get(mode, mode)

        self["autostart_status"].setText(
            "Autostart: %s (%s)" %
            ("WŁ" if enabled else "WYŁ", mode_name)
        )
  
    def update_backup_label(self):

        count = len(
            glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            )
        )

        self["key_menu"].setText("MENU - dodatki")

    def select_list(self):

        current = config.plugins.bzyk83_downloader.last_list_type.value

        choices = []

        for key in ["hb", "dual", "3x1", "4x1", "5x1", "6x1", "8x1"]:

            label = LIST_NAMES.get(key, key)

            if key == current:
                label = "✓ " + label

            choices.append((label, key))

        self.session.openWithCallback(
            self.select_list_callback,
            ChoiceBox,
            title="Wybierz listę kanałów",
            list=choices
        )
        
    def select_list_callback(self, choice):

        if not choice:
            return

        config.plugins.bzyk83_downloader.last_list_type.value = choice[1]
        config.plugins.bzyk83_downloader.last_list_type.save()

        configfile.save()

        self.refresh_version_status()
        self.update_autostart_label()

        list_type = choice[1]
        self.session.openWithCallback(
            lambda answer: self.confirm_selected_list_update(answer, list_type),
            MessageBox,
            "Czy aktualizować wybraną listę?\n\n%s" % get_list_name(list_type),
            MessageBox.TYPE_YESNO,
            default=True
        )

    def confirm_selected_list_update(self, confirmed, list_type):
        if confirmed:
            self.start_download(list_type)

    def download_selected_list(self):
        self.start_download(
            config.plugins.bzyk83_downloader.last_list_type.value
        )

    def manual_plugin_update(self):

        self["status"].setText("Aktualizacja wtyczki...")

        if update_plugin():

            self["status"].setText(
                "Restart GUI..."
            )

            os.system("sync")
            os.system("killall -9 enigma2")

        else:

            self["status"].setText(
                "Błąd aktualizacji"
            )

    def toggle_autostart(self):
        config.plugins.bzyk83_downloader.autostart.value = (
            not config.plugins.bzyk83_downloader.autostart.value
        )

        config.plugins.bzyk83_downloader.autostart.save()
        configfile.save()

        self.update_autostart_label()
        self.refresh_version_status()

    def start_download(self, list_type):

        if self.download_running:
            return
        config.plugins.bzyk83_downloader.last_list_type.value = list_type
        config.plugins.bzyk83_downloader.last_list_type.save()

        configfile.save()

        self.guiAction = None
        self.download_running = True
        self["status"].setText(
            "Pobieranie listy: %s..." % get_list_name(list_type)
        )
        self.guiTimer.start(100, False)
        threading.Thread(
            target=self.worker,
            args=(list_type,),
            daemon=True
        ).start()

    def worker(self, list_type):

        try:

            install_list(list_type)

            self.guiAction = "done"

        except Exception as e:

            self.guiAction = "error:Błąd: %s" % str(e)

    def show_backup_list(self):

        backups = sorted(
            glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            ),
            reverse=True
        )

        if not backups:

            self.session.open(
                MessageBox,
                "Brak kopii.",
                MessageBox.TYPE_INFO
            )

            return

        choices = []

        for f in backups:

            choices.append(
                (
                    os.path.basename(f),
                    f
                )
            )

        self.session.openWithCallback(
            self.restore_selected_backup,
            ChoiceBox,
            title="Wybierz kopię",
            list=choices
        )

    def restore_selected_backup(self, choice):

        if not choice:
            return

        self.selected_backup = choice[1]

        self.session.openWithCallback(
            self.restore_confirmed,
            MessageBox,
            "Przywrócić kopię:\n%s ?" %
            os.path.basename(choice[1]),
            MessageBox.TYPE_YESNO
        )
        
    def restore_confirmed(self, answer):

        if not answer:
            return

        try:

            restore_backup(self.selected_backup)

            self.session.open(
                MessageBox,
                "Kopia została przywrócona.",
                MessageBox.TYPE_INFO
            )

            self.refresh_version_status()
         
            self.update_backup_label()
            
            self.update_autostart_label()

        except Exception as e:

            self.session.open(
                MessageBox,
                str(e),
                MessageBox.TYPE_ERROR
            ) 

    def showCameraMenu(self):

        menu = [
            ("LookCam", "lookcam"),
            ("WebCamera.pl", "webcamera"),
            ("Aktualizuj AirMax Kamery", "airmax"),
            ("Kamery.Live", "kamerylive"),
            ("Aktualizuj wszystkie kamery", "all"),
        ]

        self.session.openWithCallback(
            self.cameraMenuCallback,
            ChoiceBox,
            title="Kamery internetowe",
            list=menu
        )          

    def cameraMenuCallback(self, answer):

        if not answer:
            return

        action = answer[1]

        if action == "lookcam":

            os.system(
                "python3 /usr/script/lookam_update.py >/tmp/lookcam.log 2>&1 &"
            )

            self.session.open(
                MessageBox,
                "Uruchomiono aktualizację LookCam",
                MessageBox.TYPE_INFO,
                timeout=3
            )

        elif action == "webcamera":

            os.system(
                "python3 /usr/script/webcamera_update.py >/tmp/webcamera.log 2>&1 &"
            )

            self.session.open(
                MessageBox,
                "Uruchomiono aktualizację WebCamera.pl",
                MessageBox.TYPE_INFO,
                timeout=3
            )

        elif action == "airmax":

            os.system(
                "python3 /usr/script/airmax_update.py >/tmp/airmax.log 2>&1 &"
            )

            self.session.open(
                MessageBox,
                "Uruchomiono aktualizację AirMax Kamery",
                MessageBox.TYPE_INFO,
                timeout=3
            )

        elif action == "kamerylive":

            os.system(
                "python3 /usr/script/kamery_live_update.py >/tmp/kamerylive.log 2>&1 &"
            )

            self.session.open(
                MessageBox,
                "Uruchomiono aktualizację Kamery.Live",
                MessageBox.TYPE_INFO,
                timeout=3
            )

        elif action == "all":

            os.system(
                "python3 /usr/script/lookam_update.py >/tmp/lookcam.log 2>&1 &"
            )

            os.system(
                "python3 /usr/script/webcamera_update.py >/tmp/webcamera.log 2>&1 &"
            )

            os.system(
                "python3 /usr/script/airmax_update.py >/tmp/airmax.log 2>&1 &"
            )

            os.system(
                "python3 /usr/script/kamery_live_update.py >/tmp/kamerylive.log 2>&1 &"
            )

            self.session.open(
                MessageBox,
                "Uruchomiono aktualizację wszystkich kamer",
                MessageBox.TYPE_INFO,
                timeout=3
            )

    def open_bukiety_menu(self):

        try:
            api_url = "https://api.github.com/repos/bzyk83/listy/contents/bukiety"

            data = urllib.request.urlopen(
                api_url,
                timeout=15
            ).read()

            files = json.loads(data)

            choices = []

            for item in files:

                if item.get("type") == "file":

                    name = item.get("name")

                    if name.endswith(".tv"):

                        choices.append(
                            (
                                name,
                                item.get("download_url")
                            )
                        )

            if not choices:

                self.session.open(
                    MessageBox,
                    "Brak bukietów.",
                    MessageBox.TYPE_INFO
                )
                return

            self.session.openWithCallback(
                self.download_selected_bouquet,
                ChoiceBox,
                title="Wybierz bukiet",
                list=choices
            )

        except Exception as e:

            self.session.open(
                MessageBox,
                "Błąd:\n%s" % str(e),
                MessageBox.TYPE_ERROR
            )
 
    def download_selected_bouquet(self, choice):

        if not choice:
            return

        try:

            filename = choice[0]
            url = choice[1]

            target = "/etc/enigma2/%s" % filename

            
            urllib.request.urlretrieve(
                url,
                target
            )
            append_bzyk83_bouquet_name(target)

            print("Pobrano bukiet:", target)

            bouquets_tv = "/etc/enigma2/bouquets.tv"

            entry = (
                '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet'
                % filename
            )

            lines = []

            if os.path.exists(bouquets_tv):

                with open(bouquets_tv, "r") as f:

                    lines = [
                        x.rstrip()
                        for x in f.readlines()
                        if x.strip()
                    ]

            if entry not in lines:

                lines.append(entry)

                with open(bouquets_tv, "w") as f:

                    f.write("\n".join(lines) + "\n")

                print("Dodano do bouquets.tv:", filename)

            else:

                print("Bukiet już istnieje w bouquets.tv")

            
            try:
                from enigma import eDVBDB

                db = eDVBDB.getInstance()
                db.reloadBouquets()
                db.reloadServicelist()

            except Exception as e:
                print("Reload error:", e)

            print("Przeładowano listy Enigma2")

            self.session.open(
                MessageBox,
                "Bukiet został zainstalowany:\n%s" % filename,
                MessageBox.TYPE_INFO
            )

        except Exception as e:

            self.session.open(
                MessageBox,
                "Błąd instalacji:\n%s" % str(e),
                MessageBox.TYPE_ERROR
            )



class Bzyk83TileMenu(Screen):
    """Osiem kafelkow na strone; opcjonalne logotypy w images/."""
    skin = """
    <screen name="Bzyk83TileMenu" position="center,center" size="1080,700" backgroundColor="#101923" flags="wfNoBorder">
    <widget name="heading" position="35,18" size="1010,48" font="Regular;34" foregroundColor="#58D8D2" backgroundColor="#101923" transparent="1" zPosition="3"/>
    <widget name="subtitle" position="37,69" size="1000,32" font="Regular;20" foregroundColor="#A8BAC9" backgroundColor="#101923" transparent="1" zPosition="3"/>
    <eLabel position="30,112" size="1020,2" backgroundColor="#3D6473" zPosition="0"/>
    <widget name="selection" position="39,127" size="486,119" backgroundColor="#286B70" zPosition="1"/>
<eLabel position="35,123" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_0" position="49,191" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_0" position="170,131" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="550,123" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_1" position="564,191" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_1" position="685,131" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="35,254" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_2" position="49,322" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_2" position="170,262" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="550,254" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_3" position="564,322" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_3" position="685,262" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="35,385" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_4" position="49,453" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_4" position="170,393" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="550,385" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_5" position="564,453" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_5" position="685,393" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="35,516" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_6" position="49,584" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_6" position="170,524" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="550,516" size="495,123" backgroundColor="#1B2A36" zPosition="0"/>
<widget name="tile_7" position="564,584" size="465,111" font="Regular;21" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#1B2A36" transparent="1" zPosition="3"/>
<widget name="logo_7" position="685,524" size="225,61" zPosition="3" alphatest="on"/>
<eLabel position="30,660" size="1020,2" backgroundColor="#3D6473" zPosition="0"/>
    <widget name="footer_ok" position="38,665" size="200,31" font="Regular;23" foregroundColor="#43E76A" backgroundColor="#101923" transparent="1" zPosition="3"/>
    <widget name="footer_back" position="810,665" size="230,31" font="Regular;23" halign="right" foregroundColor="#FF6565" backgroundColor="#101923" transparent="1" zPosition="3"/>
    <widget name="footer_blue" position="270,665" size="510,31" font="Regular;23" halign="center" foregroundColor="#50AFFF" backgroundColor="#101923" transparent="1" zPosition="3"/>
    </screen>
    """
    ICONS = {"lookcam": "lookcam.png", "webcamera": "webcamerapl.png",
             "airmax": "Airmax.png", "kamerylive": "KameryLive.png"}
    def __init__(self, session, title, entries, blue_callback=None, blue_label=""):
        Screen.__init__(self, session)
        self.blue_callback = blue_callback
        from Components.Pixmap import Pixmap
        self.entries = list(entries)
        self.selected = 0
        self["heading"] = Label(title)
        self["subtitle"] = Label("Wybierz kafelek i naciśnij OK")
        self["selection"] = Label("")
        for i in range(8):
            self["tile_%d" % i] = Label("")
            self["logo_%d" % i] = Pixmap()
        self["footer_ok"] = Label("OK")
        self["footer_back"] = Label("Powrót")
        self["footer_blue"] = Label(blue_label)
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {"left": self.left, "right": self.right, "up": self.up,
             "down": self.down, "ok": self.choose, "green": self.choose, "blue": self.blue_action, "red": self.cancel,
             "cancel": self.cancel}, 0)
        self.onLayoutFinish.append(self.refresh)

    def refresh(self):
        page = self.selected // 8
        for i in range(8):
            idx = page * 8 + i
            item = self.entries[idx] if idx < len(self.entries) else None
            tile = self["tile_%d" % i]
            tile.setText(item[0] if item else "")
            
            try:
                from enigma import ePoint, eSize
                if tile.instance is not None:
                    x = 49 + (i % 2) * 515
                    y = 123 + (i // 2) * 131
                    has_icon = bool(item and self.ICONS.get(item[1]))
                    tile.instance.move(ePoint(x, y + (70 if has_icon else 6)))
                    tile.instance.resize(eSize(465, 44 if has_icon else 111))
            except Exception as e:
                print("[Bzyk83] tile text layout:", e)
            logo = self["logo_%d" % i]
            logo.hide()
            if item:
                icon = self.ICONS.get(item[1])
                if icon:
                    path = os.path.join(os.path.dirname(__file__), "images", icon)
                    try:
                        if os.path.isfile(path) and logo.instance is not None:
                            logo.instance.setPixmapFromFile(path)
                            logo.show()
                    except Exception as e:
                        print("[Bzyk83] tile icon:", e)
        try:
            from enigma import ePoint
            inst = self["selection"].instance
            if inst is not None and self.entries:
                local = self.selected % 8
                inst.move(ePoint(39 + (local % 2) * 515, 127 + (local // 2) * 131))
        except Exception as e:
            print("[Bzyk83] tile highlight:", e)

    def move(self, delta):
        if self.entries:
            self.selected = (self.selected + delta) % len(self.entries)
            self.refresh()

    def left(self):
        self.move(-1)
    def right(self):
        self.move(1)
    def up(self):
        if self.entries:
            target = self.selected - 2
            self.selected = target if target >= 0 else self.selected % 2
            self.refresh()
    def down(self):
        if self.entries:
            target = self.selected + 2
            if target >= len(self.entries):
                target = self.selected % 2
                if target >= len(self.entries):
                    target = 0
            self.selected = target
            self.refresh()
    def blue_action(self):
        if self.blue_callback is not None:
            self.blue_callback(self)
    def choose(self):
        self.close(self.entries[self.selected] if self.entries else None)
    def cancel(self):
        self.close(None)


class Bzyk83StreamingScreen(Screen):
    """Siatka 3x2: trzy platformy i trzy miejsca na rozbudowe."""
    skin = """
    <screen name="Bzyk83StreamingScreen" position="center,center" size="1080,610"
            title="Platformy streamingowe" backgroundColor="#081520" flags="wfNoBorder">
        <widget name="heading" position="34,23" size="950,48" font="Regular;34"
                foregroundColor="#33E5DF" backgroundColor="#081520" transparent="1" zPosition="3" />
        <widget name="subheading" position="36,78" size="970,34" font="Regular;21"
                foregroundColor="#C3D1D8" backgroundColor="#081520" transparent="1" zPosition="3" />
        <eLabel position="30,123" size="1020,2" backgroundColor="#28AAB1" zPosition="0" />
        <eLabel position="35,147" size="326,185" backgroundColor="#557083" zPosition="0" />
        <eLabel position="37,149" size="322,181" backgroundColor="#132333" zPosition="0" />
        <eLabel position="377,147" size="326,185" backgroundColor="#557083" zPosition="0" />
        <eLabel position="379,149" size="322,181" backgroundColor="#132333" zPosition="0" />
        <eLabel position="719,147" size="326,185" backgroundColor="#557083" zPosition="0" />
        <eLabel position="721,149" size="322,181" backgroundColor="#132333" zPosition="0" />
        <eLabel position="35,351" size="326,170" backgroundColor="#557083" zPosition="0" />
        <eLabel position="37,353" size="322,166" backgroundColor="#132333" zPosition="0" />
        <eLabel position="377,351" size="326,170" backgroundColor="#557083" zPosition="0" />
        <eLabel position="379,353" size="322,166" backgroundColor="#132333" zPosition="0" />
        <eLabel position="719,351" size="326,170" backgroundColor="#557083" zPosition="0" />
        <eLabel position="721,353" size="322,166" backgroundColor="#132333" zPosition="0" />
        <widget name="tile_selection" position="39,151" size="318,177"
                backgroundColor="#35E5D5" zPosition="1" />
        <widget name="tile_selection_fill" position="43,155" size="310,169"
                backgroundColor="#105052" zPosition="2" />
        <widget name="tile_logo_0" position="98,162" size="200,75" alphatest="blend" zPosition="4" />
        <widget name="tile_logo_1" position="440,162" size="200,75" alphatest="blend" zPosition="4" />
        <widget name="tile_logo_2" position="782,162" size="200,75" alphatest="blend" zPosition="4" />
        <widget name="tile_name_0" position="51,267" size="294,42" font="Regular;25"
                foregroundColor="#FFFFFF" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <widget name="tile_name_1" position="393,267" size="294,42" font="Regular;25"
                foregroundColor="#FFFFFF" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <widget name="tile_name_2" position="735,267" size="294,42" font="Regular;25"
                foregroundColor="#FFFFFF" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <widget name="placeholder_icon_3" position="159,375" size="80,58" alphatest="blend" zPosition="4" />
        <widget name="tile_name_3" position="51,448" size="294,42" font="Regular;24" foregroundColor="#9DB2C0" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <widget name="placeholder_icon_4" position="501,375" size="80,58" alphatest="blend" zPosition="4" />
        <widget name="tile_name_4" position="393,448" size="294,42" font="Regular;24" foregroundColor="#9DB2C0" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <widget name="placeholder_icon_5" position="843,375" size="80,58" alphatest="blend" zPosition="4" />
        <widget name="tile_name_5" position="735,448" size="294,42" font="Regular;24" foregroundColor="#9DB2C0" backgroundColor="#132333" transparent="1" halign="center" zPosition="5" />
        <eLabel position="30,540" size="1020,2" backgroundColor="#28AAB1" zPosition="0" />
        <widget name="footer_ok" position="38,557" size="200,36" font="Regular;23"
                foregroundColor="#43E76A" backgroundColor="#081520" transparent="1" zPosition="3" />
        <widget name="footer_back" position="810,557" size="230,36" font="Regular;23" halign="right"
                foregroundColor="#FF6565" backgroundColor="#081520" transparent="1" zPosition="3" />
    </screen>
    """
    PLATFORMS = [
        ("SWEET.TV", "sweet", "sweettv.png"),
        ("Rakuten TV", "rakuten", "rakuten.png"),
        ("TVP VOD", "tvpvod", "tvpvod.png"),
        ("Wkrótce", None, None),
        ("Wkrótce", None, None),
        ("Wkrótce", None, None),
    ]

    def __init__(self, session):
        Screen.__init__(self, session)
        from Components.Pixmap import Pixmap
        self.selected = 0
        self["heading"] = Label("PLATFORMY STREAMINGOWE")
        self["subheading"] = Label("Wybierz serwis i naciśnij OK")
        self["tile_selection"] = Label("")
        self["tile_selection_fill"] = Label("")
        for i, (name, key, logo) in enumerate(self.PLATFORMS):
            self["tile_name_%d" % i] = Label(name)
            if logo:
                self["tile_logo_%d" % i] = Pixmap()
            else:
                self["placeholder_icon_%d" % i] = Pixmap()
        self["footer_ok"] = Label("OK: wybierz")
        self["footer_back"] = Label("Powrót")
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {"left": self.previous, "right": self.next,
             "up": self.above, "down": self.below,
             "ok": self.choose, "green": self.choose, "red": self.cancel,
             "cancel": self.cancel}, 0)
        self.onLayoutFinish.append(self.render_tiles)

    def render_tiles(self):
        try:
            from enigma import ePoint
            if self["tile_selection"].instance is not None:
                self["tile_selection"].instance.move(ePoint(39 + (self.selected % 3) * 342, 151 + (self.selected // 3) * 204))
                self["tile_selection_fill"].instance.move(ePoint(43 + (self.selected % 3) * 342, 155 + (self.selected // 3) * 204))
        except Exception as e:
            print("[Bzyk83] streaming selection:", e)
        for i, (_, _, logo) in enumerate(self.PLATFORMS):
            try:
                image_name = logo if logo else "streaming_placeholder.png"
                widget_name = ("tile_logo_%d" if logo else "placeholder_icon_%d") % i
                path = os.path.join(os.path.dirname(__file__), "images", image_name)
                if os.path.isfile(path) and self[widget_name].instance is not None:
                    self[widget_name].instance.setPixmapFromFile(path)
                    self[widget_name].show()
            except Exception as e:
                print("[Bzyk83] streaming logo:", e)

    def previous(self):
        self.selected = (self.selected // 3) * 3 + ((self.selected % 3 - 1) % 3)
        self.render_tiles()

    def next(self):
        self.selected = (self.selected // 3) * 3 + ((self.selected % 3 + 1) % 3)
        self.render_tiles()

    def above(self):
        self.selected = (self.selected - 3) % 6
        self.render_tiles()

    def below(self):
        self.selected = (self.selected + 3) % 6
        self.render_tiles()

    def choose(self):
        key = self.PLATFORMS[self.selected][1]
        if key:
            self.close(key)
        else:
            self.session.open(MessageBox, "Miejsce na kolejną platformę.", MessageBox.TYPE_INFO)

    def cancel(self):
        self.close(None)


def bzyk83_receiver_model():
    """Nazwa odbiornika z systemu, bez zaleznosci od jednego producenta."""
    try:
        from boxbranding import getMachineBrand, getMachineName
        brand = str(getMachineBrand() or "").strip()
        name = str(getMachineName() or "").strip()
        if name:
            if brand and brand.lower() not in name.lower():
                return "%s %s" % (brand, name)
            return name
    except Exception:
        pass
    for path in ("/proc/stb/info/model", "/proc/stb/info/boxtype", "/etc/model"):
        try:
            with open(path, "r") as f:
                value = f.read(80).strip()
            if value:
                return value.upper()
        except Exception:
            pass
    return "Enigma2"


class Bzyk83InfoScreen(Screen):
    """Ekran informacyjny MENU, bez powielania funkcji dashboardu."""
    skin = """
    <screen name="Bzyk83InfoScreen" position="center,center" size="1080,630"
            backgroundColor="#101923" flags="wfNoBorder">
        <widget name="heading" position="34,24" size="750,44" font="Regular;33"
                foregroundColor="#70D4C5" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="subheading" position="36,76" size="970,31" font="Regular;21"
                foregroundColor="#A8BAC9" backgroundColor="#101923" transparent="1" zPosition="2" />
        <eLabel position="30,120" size="1020,2" backgroundColor="#3D6473" zPosition="0" />
        <eLabel position="35,141" size="495,150" backgroundColor="#20313D" zPosition="0" />
        <eLabel position="550,141" size="495,150" backgroundColor="#20313D" zPosition="0" />
        <eLabel position="35,306" size="495,150" backgroundColor="#20313D" zPosition="0" />
        <eLabel position="550,306" size="495,150" backgroundColor="#20313D" zPosition="0" />
        <widget name="box_label" position="58,157" size="450,30" font="Regular;21" foregroundColor="#70D4C5" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="box_value" position="58,201" size="450,65" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="version_label" position="573,157" size="450,30" font="Regular;21" foregroundColor="#70D4C5" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="version_value" position="573,201" size="450,65" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="list_label" position="58,322" size="450,30" font="Regular;21" foregroundColor="#70D4C5" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="list_value" position="58,366" size="450,65" font="Regular;23" foregroundColor="#6AE29C" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="platform_label" position="573,322" size="450,30" font="Regular;21" foregroundColor="#70D4C5" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="platform_value" position="573,366" size="450,65" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <eLabel position="35,472" size="1010,91" backgroundColor="#20313D" zPosition="0" />
        <widget name="system_label" position="56,480" size="945,29" font="Regular;20" foregroundColor="#70D4C5" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <widget name="system_value" position="56,516" size="960,34" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#20313D" transparent="1" zPosition="2" />
        <eLabel position="30,577" size="1020,2" backgroundColor="#3D6473" zPosition="0" />
        <widget name="footer" position="36,591" size="990,29" font="Regular;20" foregroundColor="#91B9C4" backgroundColor="#101923" transparent="1" zPosition="2" />
    </screen>
    """

    def __init__(self, session, list_status=None):
        Screen.__init__(self, session)
        self["heading"] = Label("BZYK83 DOWNLOADER")
        self["subheading"] = Label("Informacje o wtyczce i jej funkcjach")
        self["box_label"] = Label("Odbiornik")
        self["box_value"] = Label(bzyk83_receiver_model())
        self["version_label"] = Label("Wersja wtyczki")
        self["version_value"] = Label(str(get_local_plugin_version()))
        self["list_label"] = Label("Listy kanałów")
        self["list_value"] = Label(list_status or "Brak danych o aktualizacji")
        self["platform_label"] = Label("Platformy streamingowe")
        self["platform_value"] = Label("SWEET.TV, Rakuten TV, TVP VOD")
        self["system_label"] = Label("System i kopie zapasowe (do 5 kopii)")
        system = "Enigma2"
        try:
            from Components.About import about
            system = about.getImageVersionString() or system
        except Exception:
            try:
                with open("/etc/issue", "r") as handle:
                    system = handle.readline().strip() or system
            except Exception:
                pass
        try:
            copies = len(glob.glob(os.path.join(BACKUP_DIR, "backup_*.zip")))
        except Exception:
            copies = 0
        self["system_value"] = Label("Obraz: %s    |    Kopie zapasowe: %d" % (system, copies))
        self["footer"] = Label("Listy kanałów  •  Streaming  •  Kamery  •  Kopie zapasowe  •  Narzędzia")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
                                     {"ok": self.close, "cancel": self.close,
                                      "red": self.close}, -1)


class Bzyk83Dashboard(DownloadListScreen):
    """Nowy ekran glowny. Logika operacji pozostaje w DownloadListScreen."""
    skin = """
    <screen name="Bzyk83Dashboard" position="center,center" size="1280,720"
            title="Bzyk83 Downloader 2.7" backgroundColor="#101923" flags="wfNoBorder">
        <widget name="dashboard_title" position="35,22" size="850,46"
                font="Regular;35" foregroundColor="#58D8D2" backgroundColor="#101923" transparent="1"  zPosition="2" />
        <widget name="dashboard_version_label" position="900,31" size="338,28"
                font="Regular;18" halign="right" foregroundColor="#A8BAC9"
                backgroundColor="#101923" transparent="1" zPosition="3" />
        <widget name="dashboard_subtitle" position="37,71" size="1000,30"
                font="Regular;21" foregroundColor="#A8BAC9" backgroundColor="#101923" transparent="1"  zPosition="2" />
        <eLabel position="30,113" size="1220,2" backgroundColor="#3D6473"  zPosition="0" />
        <eLabel position="30,132" size="340,502" backgroundColor="#1B2A36"  zPosition="0" />
        <widget name="dashboard_highlight" position="43,151" size="314,43"
                backgroundColor="#205C65" zPosition="2" />
        <widget name="dashboard_nav_0" position="53,155" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_1" position="53,199" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_2" position="53,243" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_3" position="53,287" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_4" position="53,331" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_5" position="53,375" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_nav_6" position="53,419" size="302,42"
                font="Regular;22" foregroundColor="#E5F0F4"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <eLabel position="390,132" size="860,502" backgroundColor="#1B2A36"  zPosition="0" />
        <widget name="dashboard_section" position="416,153" size="570,46"
                font="Regular;33" foregroundColor="#58D8D2"
                backgroundColor="#1B2A36" transparent="1"  zPosition="2" />
        <widget name="dashboard_logo" position="995,153" size="240,92"
                alphatest="blend"  zPosition="3" />
        <widget name="dashboard_description" position="418,245" size="790,105"
                font="Regular;24" foregroundColor="#E0EBF1"
                backgroundColor="#1B2A36" transparent="1"  zPosition="2" />
        <widget name="dashboard_detail" position="418,385" size="790,138"
                font="Regular;23" foregroundColor="#A8C1CE"
                backgroundColor="#1B2A36" transparent="1"  zPosition="2" />
        <widget name="dashboard_sat_status" position="418,448" size="790,35"
                font="Regular;23" foregroundColor="#A8C1CE"
                backgroundColor="#1B2A36" transparent="1" zPosition="3" />
        <widget name="dashboard_hint" position="418,558" size="780,54"
                font="Regular;22" foregroundColor="#58D8D2"
                backgroundColor="#1B2A36" transparent="1"  zPosition="2" />
        <eLabel position="30,653" size="1220,2" backgroundColor="#3D6473"  zPosition="0" />
        <widget name="key_red" position="40,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#FF7373" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="key_green" position="242,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#6AE29C" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="key_yellow" position="444,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#F6D26B" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="key_blue" position="646,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#79B9FF" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="key_info" position="848,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#70D4C5" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="key_menu" position="1050,672" size="190,32" font="Regular;20" halign="center"
                foregroundColor="#B5D7E4" backgroundColor="#101923" transparent="1" zPosition="2" />
        <widget name="status" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="info" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="update_info" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="last_update" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="plugin_version" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="plugin_update" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
        <widget name="autostart_status" position="0,0" size="1,1" font="Regular;1" transparent="1"  zPosition="2" />
    </screen>
    """
    DASH_ITEMS = [
        ("Listy kanałów", "sat"),
        ("Platformy streamingowe", "streaming"),
        ("Kamery internetowe", "cameras"),
        ("Dodatkowe bukiety", "bouquets"),
        ("Kopie zapasowe", "backup"),
        ("Narzędzia", "tools")
    ]

    def __init__(self, session):
        DownloadListScreen.__init__(self, session)
        from Components.Pixmap import Pixmap
        self["dashboard_title"] = Label("BZYK83  DOWNLOADER")
        self["dashboard_version_label"] = Label("Wersja: %s" % get_local_plugin_version())
        self["dashboard_subtitle"] = Label("Centrum kanałów i usług Enigma2  |  %s" % bzyk83_receiver_model())
        self.dashboard_index = 0
        self["dashboard_highlight"] = Label("")
        for i, item in enumerate(self.DASH_ITEMS):
            self["dashboard_nav_%d" % i] = Label(item[0])
        self["dashboard_nav_6"] = Label("")
        self["dashboard_section"] = Label("")
        self["dashboard_description"] = Label("")
        self["dashboard_detail"] = Label("")
        self["dashboard_sat_status"] = Label("")
        self["dashboard_hint"] = Label("")
        self["dashboard_logo"] = Pixmap()
        self["key_info"] = Label("")
        self["key_red"].setText("Wyjście")
        self["key_green"].setText("Kopie")
        self["key_yellow"].setText("Aktualizacja wtyczki")
        self["key_blue"].setText("Narzędzia")
        self["key_info"].setText("INFO")
        self["key_menu"].setText("MENU")
        self["dashboard_actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "MenuActions", "InfobarEPGActions", "InfoActions"],
            {"info": self.dashboard_description_info, "up": self.nav_up, "down": self.nav_down,
             "ok": self.dashboard_open, "green": self.dashboard_backup,
             "yellow": self.dashboard_plugin_update, "blue": self.dashboard_tools,
             "menu": self.dashboard_about, "red": self.close, "cancel": self.close}, 0)
        self["actions"].setEnabled(False)
        
        self.onLayoutFinish.remove(self.layoutFinished)
        self.onLayoutFinish.append(self.dashboard_refresh)
        
        self.dashboard_list_versions = {}
        self.dashboard_check_running = False
        self.dashboard_check_result = None
        
        self.dashboard_refresh()
        
        self.dashboard_version_timer = eTimer()
        self.dashboard_version_timer.callback.append(self.dashboard_version_tick)
        self.onClose.append(self.dashboard_stop_version_timer)
        self.dashboard_start_version_check()

    def layoutFinished(self):
        DownloadListScreen.layoutFinished(self)
        self["key_red"].setText("Wyjście")
        self["key_green"].setText("Kopie")
        self["key_yellow"].setText("Aktualizacja wtyczki")
        self["key_blue"].setText("Narzędzia")
        self["key_info"].setText("INFO")
        self["key_menu"].setText("MENU")

    def nav_up(self):
        self.dashboard_index = (self.dashboard_index - 1) % len(self.DASH_ITEMS)
        self.dashboard_refresh()
        if self.dashboard_current() == "sat":
            self.dashboard_start_version_check()

    def nav_down(self):
        self.dashboard_index = (self.dashboard_index + 1) % len(self.DASH_ITEMS)
        self.dashboard_refresh()
        if self.dashboard_current() == "sat":
            self.dashboard_start_version_check()

    def dashboard_current(self):
        return self.DASH_ITEMS[self.dashboard_index][1]

    def dashboard_refresh(self):
        
        try:
            from enigma import ePoint
            if self["dashboard_highlight"].instance is not None:
                self["dashboard_highlight"].instance.move(
                    ePoint(43, 151 + self.dashboard_index * 44))
        except Exception as e:
            print("[Bzyk83] highlight:", e)
        for i, item in enumerate(self.DASH_ITEMS):
            label = self["dashboard_nav_%d" % i]
            label.setText(("> " if i == self.dashboard_index else "  ") + item[0])
        section = self.dashboard_current()
        info = {
            "sat": ("LISTY KANAŁÓW", "Pobieranie i aktualizacja list kanałów.",
                    "Wybrana lista: %s" % LIST_NAMES.get(
                        config.plugins.bzyk83_downloader.last_list_type.value, "?"),
                    "OK: wybierz listę"),
            "streaming": ("PLATFORMY STREAMINGOWE", "SWEET.TV  |  Rakuten TV  |  TVP VOD",
                          "Dostępne platformy: 3",
                          "OK: wybierz platformę streamingową"),
            "cameras": ("KAMERY INTERNETOWE", "LookCam, WebCamera.pl, AirMax i Kamery.Live.",
                        "Wybierz serwis lub zaktualizuj wszystkie kamery.",
                        "OK: otwórz menu kamer"),
            "bouquets": ("DODATKOWE BUKIETY", "Zarządzanie dodatkowymi bukietami.",
                         "Pobieranie kanałów z dostępnych źródeł.",
                         "OK: otwórz listę bukietów"),
            "backup": ("KOPIE ZAPASOWE", "Kopie list kanałów.",
                       "Zapisanych kopii: %d" % len(glob.glob(os.path.join(BACKUP_DIR, "backup_*.zip"))),
                       "OK: otwórz kopie zapasowe"),
            "tools": ("NARZĘDZIA", "Ustawienia i konserwacja dekodera.",
                      "Satellites.xml, haslo i aktualizacja wtyczki.",
                      "OK: otwórz narzędzia")
        }
        if section == "sat":
            mode = config.plugins.bzyk83_downloader.last_list_type.value
            local = get_local_list_version()
            remote = self.dashboard_list_versions.get(mode)
            if remote is None:
                status = "Sprawdzanie aktualizacji..."
            elif not remote:
                status = "Brak polaczenia z serwerem wersji"
            elif str(local).strip() == str(remote).strip():
                status = "Lista aktualna (%s)" % remote
            else:
                status = "DOSTEPNA AKTUALIZACJA (%s)" % remote
            info["sat"] = ("LISTY KANAŁÓW",
                "Wybrana lista: %s" % LIST_NAMES.get(mode, mode),
                "Wersja zainstalowana: %s\nOstatnia aktualizacja: %s" %
                (local, get_last_update()),
                "OK: wybierz listę")
        else:
            status = ""
        title, desc, detail, hint = info[section]
        self["dashboard_section"].setText(title)
        self["dashboard_description"].setText(desc)
        self["dashboard_detail"].setText(detail)
        self["dashboard_sat_status"].setText(status)
        try:
            from enigma import gRGB
            inst = self["dashboard_sat_status"].instance
            if inst is not None:
                is_new = (section == "sat" and bool(remote) and
                          str(local).strip() != str(remote).strip())
                inst.setForegroundColor(gRGB(0x6AE29C if is_new else 0xA8C1CE))
        except Exception as e:
            print("[Bzyk83] sat status color:", e)
        self["dashboard_hint"].setText(hint)
        logo = {"sweet": "sweettv.png", "rakuten": "rakuten.png"}.get(section)
        try:
            self["dashboard_logo"].hide()
            if logo:
                path = os.path.join(os.path.dirname(__file__), "images", logo)
                if os.path.isfile(path):
                    self["dashboard_logo"].instance.setPixmapFromFile(path)
                    self["dashboard_logo"].show()
        except Exception as e:
            print("[Bzyk83] logo:", e)

    def dashboard_open(self):
        section = self.dashboard_current()
        if section == "sat":
            self.select_list()
        elif section == "streaming":
            self.session.openWithCallback(self.dashboard_streaming_chosen, Bzyk83StreamingScreen)
        elif section == "cameras":
            self.showCameraMenu()
        elif section == "bouquets":
            self.open_bukiety_menu()
        elif section == "backup":
            self.dashboard_backup()
        elif section == "tools":
            self.dashboard_tools()

    def dashboard_streaming_chosen(self, platform):
        
        if platform == "sweet":
            self.show_sweet_menu()
        elif platform == "rakuten":
            self.show_rakuten_menu()
        elif platform == "tvpvod":
            self.show_tvpvod_menu()

    def dashboard_tiles(self, title, entries, callback, blue_callback=None, blue_label=""):
        self.session.openWithCallback(callback, Bzyk83TileMenu, title, entries, blue_callback, blue_label)

    def dashboard_toggle_list_autoupdate(self, screen):
        setting = config.plugins.bzyk83_downloader.list_autoupdate
        setting.value = not setting.value
        setting.save()
        configfile.save()
        screen["footer_blue"].setText("Autoupdate: %s" % ("WŁ" if setting.value else "WYŁ"))
        self["status"].setText("Automatyczna aktualizacja list: %s" % ("WŁ" if setting.value else "WYŁ"))
        if setting.value:
            threading.Thread(target=silent_autostart_update, daemon=True).start()

    def dashboard_return_streaming(self, answer, callback):
        if not answer:
            self.session.openWithCallback(self.dashboard_streaming_chosen, Bzyk83StreamingScreen)
        else:
            callback(answer)

    def dashboard_backup(self):
        self.dashboard_tiles("KOPIE ZAPASOWE", [
            ("Utwórz kopię list", "backup"),
            ("Przywróć kopię", "restore"),
            ("Usuń wszystkie kopie", "delete")], self.backupMenuCallback)

    def dashboard_tools(self):
        self.dashboard_tiles("NARZĘDZIA", [
            ("Aktualizacja satellites.xml", "satellites"),
            ("Reset hasła tunera", "password"),
            ("Port OSCam WebIF: 8888", "oscam_webif"),
            ("Aktualizacja wtyczki", "plugin")], self.dashboard_tool_callback)

    def select_list(self):
        current = config.plugins.bzyk83_downloader.last_list_type.value
        entries = [(("✓  " if key == current else "") + LIST_NAMES.get(key, key), key)
                   for key in ["hb", "dual", "3x1", "4x1", "5x1", "6x1", "8x1"]]
        entries.append(("Aktualizuj wybraną listę", "__update__"))
        self.dashboard_tiles("LISTY KANAŁÓW", entries, self.dashboard_list_tile_callback,
                             self.dashboard_toggle_list_autoupdate,
                             "Autoupdate: %s" % ("WŁ" if config.plugins.bzyk83_downloader.list_autoupdate.value else "WYŁ"))

    def dashboard_list_tile_callback(self, choice):
        if not choice:
            return
        if choice[1] == "__update__":
            self.download_selected_list()
        else:
            self.select_list_callback(choice)
            self.dashboard_refresh()

    def showCameraMenu(self):
        self.dashboard_tiles("KAMERY INTERNETOWE", [
            ("LookCam", "lookcam"),
            ("WebCamera.pl", "webcamera"),
            ("AirMax", "airmax"),
            ("Kamery.Live", "kamerylive"),
            ("Aktualizuj wszystkie", "all")], self.cameraMenuCallback)

    def show_sweet_menu(self):
        self.dashboard_tiles("SWEET.TV", [
            ("Aktualizuj kanały i EPG", "update"),
            ("Automatyczne odświeżanie: %s" % ("WL" if self.sweet_cron_enabled() else "WYL"), "cron"),
            ("Autostart serwera EPG: %s" % ("WL" if self.sweet_epg_autostart() else "WYL"), "epgserver"),
            ("Status SWEET.TV", "status"),
            ("Ostatni wynik", "log"),
            ("Logowanie SWEET.TV", "login")], lambda answer: self.dashboard_return_streaming(answer, self.sweet_menu_callback))

    def show_rakuten_menu(self):
        self.dashboard_tiles("RAKUTEN TV", [
            ("Aktualizuj kanały", "update"),
            ("Ostatni wynik", "log")], lambda answer: self.dashboard_return_streaming(answer, self.rakuten_menu_callback))

    def show_tvpvod_menu(self):
        self.dashboard_tiles("TVP VOD", [
            ("Aktualizuj bukiet", "update"),
            ("Status resolvera", "status"),
            ("Uruchom resolver", "start"),
            ("Zatrzymaj resolver", "stop"),
            ("Przeładuj bukiety w tle", "reload"),
            ("Log przeładowania", "log")], lambda answer: self.dashboard_return_streaming(answer, self.tvpvod_menu_callback))

    def tvpvod_menu_callback(self, answer):
        if not answer:
            return
        action = answer[1]
        if action == "log":
            try:
                with open("/tmp/tvp_bouquet_reload.log", "rb") as f:
                    msg = f.read()[-3000:].decode("utf-8", "replace")
            except Exception as exc:
                msg = "Brak logu: %s" % exc
            self.session.open(MessageBox, msg or "Log pusty", MessageBox.TYPE_INFO)
            return
        if action == "update":
            self.session.openWithCallback(self.tvpvod_update_confirmed, MessageBox,
                "Zaktualizować TVP VOD 0.4.1?\nZostanie wykonana kopia zapasowa.",
                MessageBox.TYPE_YESNO)
            return
        script = "/usr/script/tvp.py"
        if not os.path.isfile(script):
            self.session.open(MessageBox, "Brak resolvera TVP VOD: " + script,
                              MessageBox.TYPE_ERROR)
            return
        flags = {"status": "--status", "start": "--start", "stop": "--stop", "reload": "--reload"}
        if action in flags:
            self.tvpvod_run(["/usr/bin/python3", script, flags[action]])

    def tvpvod_update_confirmed(self, answer):
        if not answer:
            return
        installer = os.path.join(os.path.dirname(__file__), "tvpvod", "install_update.py")
        if not os.path.isfile("/usr/script/tvp.py"):
            self.session.open(MessageBox,
                "Najpierw zainstaluj samodzielny TVP VOD. Aktualizator wymaga istniejącej instalacji.",
                MessageBox.TYPE_ERROR)
            return
        if not os.path.isfile(installer):
            self.session.open(MessageBox, "Brak instalatora: " + installer,
                              MessageBox.TYPE_ERROR)
            return
        self.tvpvod_run(["/usr/bin/python3", installer])

    def tvpvod_run(self, command):
        if getattr(self, "tvpvod_busy", False):
            self.session.open(MessageBox, "Operacja TVP VOD już trwa.", MessageBox.TYPE_INFO)
            return
        self.tvpvod_busy = True
        self.tvpvod_last_action = "update" if command[-1].endswith("install_update.py") else "other"
        self.tvpvod_chunks = []
        self.tvpvod_process = eConsoleAppContainer()
        self.tvpvod_process.dataAvail.append(self.tvpvod_output)
        self.tvpvod_process.appClosed.append(self.tvpvod_finished)
        try:
            result = self.tvpvod_process.execute(command[0], *command)
            if result:
                self.tvpvod_busy = False
                self.session.open(MessageBox, "Nie udało się uruchomić operacji TVP VOD.", MessageBox.TYPE_ERROR)
        except Exception as exc:
            self.tvpvod_busy = False
            self.session.open(MessageBox, "Błąd TVP VOD: %s" % exc, MessageBox.TYPE_ERROR)

    def tvpvod_output(self, data):
        if isinstance(data, bytes):
            data = data.decode("utf-8", "replace")
        self.tvpvod_chunks.append(data)
        if len(self.tvpvod_chunks) > 100:
            self.tvpvod_chunks = self.tvpvod_chunks[-100:]

    def tvpvod_finished(self, result):
        self.tvpvod_busy = False
        message = "".join(self.tvpvod_chunks)[-3000:] or "Brak dodatkowych informacji"
        if result == 0 and getattr(self, "tvpvod_last_action", "") == "update":
            message = "Załadowano 42 kanały."
        self.session.open(MessageBox,
            message if result == 0 and getattr(self, "tvpvod_last_action", "") == "update" else
            "TVP VOD: %s\n\n%s" % ("OK" if result == 0 else "Błąd (%s)" % result, message),
            MessageBox.TYPE_INFO if result == 0 else MessageBox.TYPE_ERROR)

    def show_satellites_menu(self):
        self.dashboard_tiles("SATELLITES.XML", [
            ("Wybierz satelity", "choose"),
            ("Pobierz wszystkie", "all")], self.satellites_mode_callback)

    def dashboard_stop_version_timer(self):
        try:
            self.dashboard_version_timer.stop()
        except Exception:
            pass

    def dashboard_start_version_check(self):
        mode = config.plugins.bzyk83_downloader.last_list_type.value
        if self.dashboard_check_running or mode in self.dashboard_list_versions:
            return
        self.dashboard_check_running = True
        self.dashboard_check_result = None
        def worker():
            try:
                result = get_remote_version(mode)
            except Exception:
                result = ""
            self.dashboard_check_result = (mode, result)
        threading.Thread(target=worker, daemon=True).start()
        self.dashboard_version_timer.start(250, True)

    def dashboard_version_tick(self):
        result = self.dashboard_check_result
        if result is None:
            self.dashboard_version_timer.start(250, True)
            return
        mode, remote = result
        self.dashboard_list_versions[mode] = remote
        self.dashboard_check_running = False
        self.dashboard_check_result = None
        if self.dashboard_current() == "sat":
            self.dashboard_refresh()

    def dashboard_plugin_update(self):
        
        if getattr(self, "dashboard_plugin_check_running", False):
            self.session.open(MessageBox, "Trwa sprawdzanie aktualizacji wtyczki.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.dashboard_plugin_check_running = True
        self.session.open(MessageBox, "Sprawdzanie wersji wtyczki...", MessageBox.TYPE_INFO, timeout=3)
        self.dashboard_plugin_check_result = None
        def worker():
            try:
                remote = get_remote_plugin_version()
            except Exception:
                remote = ""
            self.dashboard_plugin_check_result = remote
        threading.Thread(target=worker, daemon=True).start()
        self.dashboard_plugin_timer = eTimer()
        self.dashboard_plugin_timer.callback.append(self.dashboard_plugin_check_tick)
        self.dashboard_plugin_timer.start(250, True)

    def dashboard_plugin_check_tick(self):
        remote = self.dashboard_plugin_check_result
        if remote is None:
            self.dashboard_plugin_timer.start(250, True)
            return
        self.dashboard_plugin_check_running = False
        self.dashboard_plugin_timer.stop()
        local = get_local_plugin_version()
        if not remote:
            self.session.open(MessageBox, "Nie mozna sprawdzic wersji wtyczki. Sprawdz polaczenie internetowe.", MessageBox.TYPE_ERROR, timeout=7)
        elif str(remote).strip() == str(local).strip():
            self.session.open(MessageBox, "Wtyczka jest aktualna.\nWersja: %s" % local, MessageBox.TYPE_INFO, timeout=7)
        else:
            self.session.openWithCallback(self.dashboard_confirm_plugin_update, MessageBox,
                "Wykryto inna wersje wtyczki.\n\nZainstalowana: %s\nNa serwerze: %s\n\nPobrac i zainstalowac aktualizacje?\nPo instalacji nastapi restart GUI." % (local, remote),
                MessageBox.TYPE_YESNO, default=False)

    def dashboard_confirm_plugin_update(self, confirmed):
        if confirmed:
            self.manual_plugin_update()

    def dashboard_description_info(self):
        description = (
            "BZYK83DOWNLOADER\n\n"
            "Centrum zarządzania listami kanałów i dodatkowymi usługami "
            "dla odbiorników Enigma2.\n\n"
            "• Pobieranie i aktualizowanie list kanałów.\n"
            "• Automatyczne sprawdzanie i instalowanie aktualizacji list.\n"
            "• Generowanie i odświeżanie bukietów SWEET.TV, Rakuten TV i TVP VOD.\n"
            "• Tworzenie i przywracanie kopii zapasowych list kanałów.\n"
            "• Narzędzia do obsługi odbiornika i aktualizacji wtyczki.\n\n"
            "Bzyk83Downloader — listy, streaming i narzędzia w jednym miejscu."
        )
        self.session.open(MessageBox, description, MessageBox.TYPE_INFO)

    def dashboard_about(self):
        try:
            mode = config.plugins.bzyk83_downloader.last_list_type.value
            remote = getattr(self, "dashboard_list_versions", {}).get(mode)
            local = get_local_list_version()
            if remote and str(remote).strip() != str(local).strip():
                status = "Dostępna aktualizacja: %s" % remote
            elif remote:
                status = "Lista aktualna"
            else:
                status = "Nie sprawdzono wersji"
            self.session.open(Bzyk83InfoScreen, status)
        except Exception as e:
            print("[Bzyk83] info screen error:", e)
            self.session.open(MessageBox, "Nie można otworzyć informacji: %s" % e,
                              MessageBox.TYPE_ERROR, timeout=8)

    def dashboard_oscam_webif_confirm(self):
        self.session.openWithCallback(
            self.dashboard_oscam_webif_apply,
            MessageBox,
            "Ustawić port panelu WWW OSCam (WebIF) na 8888?\n"
            "Nie zmienia to portów czytników ani protokołów OSCam.\n"
            "Po zmianie należy zrestartować OSCam.",
            MessageBox.TYPE_YESNO)

    def dashboard_oscam_webif_apply(self, confirmed):
        if not confirmed:
            return
        
        paths = [
            "/etc/tuxbox/config/oscam/oscam.conf",
            "/etc/tuxbox/config/oscam.conf",
            "/etc/oscam/oscam.conf",
            "/usr/keys/oscam.conf",
            "/usr/local/etc/oscam.conf",
        ]
        found = [p for p in paths if os.path.isfile(p)]
        if len(found) != 1:
            message = ("Nie znaleziono pliku oscam.conf."
                       if not found else
                       "Znaleziono kilka konfiguracji OSCam. Nie zmieniono żadnej:\n" + "\n".join(found))
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=12)
            return
        path = found[0]
        try:
            with open(path, "rb") as f:
                raw = f.read()
            content = raw.decode("utf-8")
            newline = "\r\n" if "\r\n" in content else "\n"
            lines = content.splitlines(True)
            section_start = None
            section_end = len(lines)
            for i, line in enumerate(lines):
                match = re.match(r"^\s*\[([^]]+)\]\s*(?:[#;].*)?$", line)
                if match:
                    if section_start is not None:
                        section_end = i
                        break
                    if match.group(1).strip().lower() == "webif":
                        section_start = i
            if section_start is None:
                raise ValueError("Brak sekcji [webif] w oscam.conf. Nic nie zmieniono.")
            matches = [i for i in range(section_start + 1, section_end)
                       if re.match(r"^\s*httpport\s*=", lines[i], re.I)]
            if len(matches) > 1:
                raise ValueError("W sekcji [webif] jest więcej niż jeden httpport. Nic nie zmieniono.")
            if matches:
                idx = matches[0]
                
                match = re.match(r"^(\s*httpport\s*=\s*)(\+?)(\d+)(\s*(?:[#;].*)?)(\r?\n)?$", lines[idx], re.I)
                if not match:
                    raise ValueError("Nietypowa wartość httpport. Nic nie zmieniono.")
                lines[idx] = match.group(1) + match.group(2) + "8888" + match.group(4) + (match.group(5) or "")
            else:
                if not lines[section_end - 1].endswith(("\n", "\r")):
                    lines[section_end - 1] += newline
                lines.insert(section_end, "httpport = 8888" + newline)
            updated = "".join(lines).encode("utf-8")
            if updated == raw:
                self.session.open(MessageBox, "Port OSCam WebIF jest już ustawiony na 8888.", MessageBox.TYPE_INFO, timeout=7)
                return
            import shutil
            import stat
            import tempfile
            backup = path + ".bzyk83.bak"
            shutil.copy2(path, backup)
            fd, tmp = tempfile.mkstemp(prefix=".oscam-bzyk83-", dir=os.path.dirname(path))
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(updated)
                    f.flush()
                    os.fsync(f.fileno())
                os.chmod(tmp, stat.S_IMODE(os.stat(path).st_mode))
                os.replace(tmp, path)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            self.session.open(MessageBox,
                              "Ustawiono port OSCam WebIF na 8888.\n"
                              "Kopia: %s\nUruchom ponownie OSCam, aby zastosować zmianę." % backup,
                              MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, "Nie zmieniono portu OSCam: %s" % exc,
                              MessageBox.TYPE_ERROR, timeout=12)

    def dashboard_tool_callback(self, answer):
        if not answer:
            return
        if answer[1] == "satellites":
            self.show_satellites_menu()
        elif answer[1] == "password":
            self.show_password_menu()
        elif answer[1] == "plugin":
            self.manual_plugin_update()
        elif answer[1] == "oscam_webif":
            self.dashboard_oscam_webif_confirm()

def main(session, **kwargs):
    session.open(Bzyk83Dashboard)

AUTOUPDATE_INTERVAL_MS = 12 * 60 * 60 * 1000
AUTOUPDATE_INITIAL_MS = 60 * 1000
AUTOUPDATE_LOG = "/tmp/bzyk83_list_autoupdate.log"
update_lock = threading.Lock()
gTimer = None

def silent_autostart_update():
    """Pobierz nową wersję wybranej listy tylko po wykryciu zmiany wersji."""
    if not config.plugins.bzyk83_downloader.list_autoupdate.value:
        return
    if update_lock.locked():
        return
    try:
        list_type = config.plugins.bzyk83_downloader.last_list_type.value
        local_version = get_local_list_version()
        remote_version = get_remote_version(list_type)
        if not remote_version or local_version == remote_version:
            return
        install_list(list_type)
        message = "[Bzyk83] Autoupdate %s: %s -> %s" % (list_type, local_version, remote_version)
        print(message)
        with open(AUTOUPDATE_LOG, "a") as log:
            log.write("%s %s\n" % (datetime.datetime.now().isoformat(), message))
    except Exception as exc:
        print("[Bzyk83] Autoupdate error:", exc)
        try:
            with open(AUTOUPDATE_LOG, "a") as log:
                log.write("%s ERROR: %s\n" % (datetime.datetime.now().isoformat(), exc))
        except Exception:
            pass

def timer_callback():
    global gTimer
    threading.Thread(target=silent_autostart_update, daemon=True).start()
    if gTimer is not None:
        gTimer.start(AUTOUPDATE_INTERVAL_MS, True)

def autostart(reason, **kwargs):
    global gTimer
    if reason == 0 and gTimer is None:
        gTimer = eTimer()
        try:
            gTimer.timeout.connect(timer_callback)
        except Exception:
            gTimer.callback.append(timer_callback)
        gTimer.start(AUTOUPDATE_INITIAL_MS, True)
    elif reason == 1 and gTimer is not None:
        gTimer.stop()
        gTimer = None

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Bzyk83 Downloader",
            description="Aktualizacja list kanałów",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]


def _bzyk83_list_worker(self, list_type):
    import traceback
    try:
        install_list(list_type)
        self.guiAction = "done"
    except Exception as exc:
        details = traceback.format_exc()
        print("[Bzyk83] Aktualizacja listy:\n" + details)
        try:
            with open("/tmp/bzyk83_list_error.log", "w") as log:
                log.write(details)
        except Exception:
            pass
        self.guiAction = "error:%s: %s" % (
            type(exc).__name__, exc
        )


def _bzyk83_list_gui_update(self):
    action = self.guiAction
    if action is None:
        return

    self.guiTimer.stop()
    self.guiAction = None
    self.download_running = False

    if action == "done":
        text = "Lista została pobrana i przeładowana w Enigma2."
        kind = MessageBox.TYPE_INFO
    else:
        text = "Nie udało się zaktualizować listy:\n\n"
        text += action[6:]
        text += "\n\nSzczegóły: /tmp/bzyk83_list_error.log"
        kind = MessageBox.TYPE_ERROR

    self["status"].setText(text)
    if hasattr(self, "dashboard_refresh"):
        self.dashboard_refresh()
    self.session.open(MessageBox, text, kind)


DownloadListScreen.worker = _bzyk83_list_worker
DownloadListScreen.guiUpdate = _bzyk83_list_gui_update


def _bzyk83_result_5s(self):
    action = self.guiAction
    if action is None:
        return

    self.guiTimer.stop()
    self.guiAction = None
    self.download_running = False

    if action == "done":
        text = "Lista została pobrana i przeładowana."
        kind = MessageBox.TYPE_INFO
    else:
        text = "Błąd aktualizacji listy:\n\n" + action[6:]
        kind = MessageBox.TYPE_ERROR

    self["status"].setText(text)
    if hasattr(self, "dashboard_refresh"):
        self.dashboard_refresh()
    self.session.open(MessageBox, text, kind, timeout=5)


DownloadListScreen.guiUpdate = _bzyk83_result_5s


def _bzyk83_install_oscam(self):
    import shutil
    import tempfile
    from shlex import quote
    from Screens.Console import Console

    if not shutil.which("opkg"):
        self.session.open(
            MessageBox, "Nie znaleziono opkg.",
            MessageBox.TYPE_ERROR, timeout=5
        )
        return

    tmp = tempfile.mkdtemp(prefix="bzyk83-oscam-")
    listing = os.path.join(tmp, "packages")
    ready = os.path.join(tmp, "ready")
    installed = os.path.join(tmp, "installed")

    def cleanup():
        shutil.rmtree(tmp, ignore_errors=True)

    def message(text, error=False):
        self.session.open(
            MessageBox, text,
            MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO,
            timeout=5
        )

    def installation_done(*args):
        success = os.path.isfile(installed)
        cleanup()
        if success:
            message(
                "OSCam został zainstalowany.\n"
                "Wybierz go w menedżerze softcam tunera."
            )
        else:
            message(
                "Instalacja OSCam nie została zakończona.\n"
                "Sprawdź wynik w oknie instalacji.",
                True
            )

    def selected(answer):
        if not answer:
            cleanup()
            return

        package = answer[1]

        def confirmed(yes):
            if not yes:
                cleanup()
                return

            command = (
                "opkg --force-confold install %s && touch %s"
                % (quote(package), quote(installed))
            )
            self.session.openWithCallback(
                installation_done, Console,
                title="Instalacja OSCam: " + package,
                cmdlist=[command],
                closeOnSuccess=True
            )

        self.session.openWithCallback(
            confirmed, MessageBox,
            "Zainstalować pakiet z repozytorium tunera?\n\n"
            + package,
            MessageBox.TYPE_YESNO,
            default=False
        )

    def repository_done(*args):
        if not os.path.isfile(ready):
            cleanup()
            message(
                "Nie udało się odczytać repozytorium.\n"
                "Sprawdź wynik w oknie pobierania.",
                True
            )
            return

        try:
            with open(listing, "r", errors="replace") as handle:
                names = {
                    line.split(" - ", 1)[0].strip()
                    for line in handle
                }

            packages = sorted(
                name for name in names
                if re.fullmatch(
                    r"[A-Za-z0-9][A-Za-z0-9.+_-]*", name
                )
                and "oscam" in name.lower()
                and not re.search(
                    r"(?:^|[-_])(dev|dbg|doc|src|config|configs)"
                    r"(?:$|[-_])",
                    name.lower()
                )
            )
        except Exception as exc:
            cleanup()
            message("Błąd odczytu pakietów: %s" % exc, True)
            return

        if not packages:
            cleanup()
            message(
                "Repozytorium tego obrazu nie udostępnia OSCam."
            )
            return

        self.session.openWithCallback(
            selected, ChoiceBox,
            title="OSCam — wybierz pakiet z repozytorium",
            list=[(name, name) for name in packages]
        )

    command = "opkg update && opkg list > %s && touch %s" % (
        quote(listing), quote(ready)
    )
    self.session.openWithCallback(
        repository_done, Console,
        title="OSCam — sprawdzanie repozytorium",
        cmdlist=[command],
        closeOnSuccess=True
    )


def _bzyk83_tools_with_oscam(self):
    def chosen(answer):
        if answer and answer[1] == "oscam_install":
            _bzyk83_install_oscam(self)
        else:
            self.dashboard_tool_callback(answer)

    self.dashboard_tiles(
        "NARZĘDZIA",
        [
            ("Instalacja OSCam", "oscam_install"),
            ("Aktualizacja satellites.xml", "satellites"),
            ("Reset hasła tunera", "password"),
            ("Port OSCam WebIF: 8888", "oscam_webif"),
            ("Aktualizacja wtyczki", "plugin"),
        ],
        chosen
    )


Bzyk83Dashboard.dashboard_tools = _bzyk83_tools_with_oscam

def _bzyk83_dark_skin(skin):
    colors = {
        "#101923": "#30050507",
        "#081520": "#30050507",
        "#1B2A36": "#400B0D10",
        "#132333": "#400B0D10",
        "#20313D": "#400B0D10",
        "#557083": "#002A343B",
        "#3D6473": "#002A343B",
        "#205C65": "#001B4145",
        "#286B70": "#001B4145",
        "#105052": "#001B4145",
    }
    return re.sub(
        r'backgroundColor="(#[0-9A-Fa-f]{6})"',
        lambda match: 'backgroundColor="%s"' % colors.get(
            match.group(1).upper(), match.group(1)
        ),
        skin
    )


for _bzyk83_screen in (
    Bzyk83Dashboard,
    Bzyk83TileMenu,
    Bzyk83StreamingScreen,
    Bzyk83InfoScreen,
):
    _bzyk83_screen.skin = _bzyk83_dark_skin(
        _bzyk83_screen.skin
    )

# Sprawdzanie wersji po otwarciu wtyczki.
class Bzyk83PluginUpdater:
    def __init__(self, session):
        self.session = session
        self.busy = False
        self.result = None
        self.timer = eTimer()
        try:
            self.connection = self.timer.timeout.connect(self.tick)
        except AttributeError:
            self.timer.callback.append(self.tick)

    @staticmethod
    def newer(remote, local):
        def number(value):
            value = str(value).strip().lstrip("vV")
            if not re.fullmatch(r"\d+(?:[._-]\d+)*", value):
                return None
            parts = [int(x) for x in re.split(r"[._-]", value)]
            while parts and parts[-1] == 0:
                parts.pop()
            return tuple(parts)
        remote, local = number(remote), number(local)
        return remote is not None and local is not None and remote > local

    def check(self):
        if self.busy:
            return
        self.busy = True
        self.mode = "check"
        self.result = None

        def worker():
            try:
                self.result = (get_remote_plugin_version(), get_local_plugin_version())
            except Exception:
                self.result = ("", "")

        threading.Thread(target=worker, daemon=True).start()
        self.timer.start(250, True)

    def tick(self):
        if self.result is None:
            self.timer.start(250, True)
            return
        result = self.result
        self.result = None
        if self.mode == "install":
            self.progress.close(bool(result[0]))
            return
        remote, local = result
        if self.newer(remote, local):
            self.session.openWithCallback(
                self.answer, MessageBox,
                "Dostępna jest nowa wersja wtyczki.\n\n"
                "Zainstalowana: %s\nNowa: %s\n\n"
                "Czy zaktualizować?\nPo instalacji nastąpi restart GUI."
                % (local, remote),
                MessageBox.TYPE_YESNO, default=False)
        else:
            self.busy = False

    def answer(self, yes):
        self.busy = False
        if yes:
            self.install()

    def install(self):
        if self.busy:
            return
        self.busy = True
        self.mode = "install"
        self.result = None
        self.progress = self.session.openWithCallback(
            self.installed, MessageBox,
            "Trwa aktualizacja wtyczki...",
            MessageBox.TYPE_INFO, timeout=0, enable_input=False)

        def worker():
            try:
                self.result = (bool(update_plugin()),)
            except Exception:
                self.result = (False,)

        threading.Thread(target=worker, daemon=True).start()
        self.timer.start(250, True)

    def installed(self, success=False):
        self.progress = None
        if success:
            self.session.openWithCallback(
                self.restart, MessageBox,
                "Wtyczka została zaktualizowana.\n"
                "Za 5 sekund nastąpi restart GUI.",
                MessageBox.TYPE_INFO, timeout=5, enable_input=False)
        else:
            self.busy = False
            self.session.open(
                MessageBox,
                "Aktualizacja wtyczki nie powiodła się.\n"
                "GUI nie zostanie zrestartowane.",
                MessageBox.TYPE_ERROR, timeout=8)

    def restart(self, *args):
        self.session.open(TryQuitMainloop, 3)


_bzyk83_plugin_updater = None


def _bzyk83_get_plugin_updater(session):
    global _bzyk83_plugin_updater
    if (_bzyk83_plugin_updater is None
            or _bzyk83_plugin_updater.session is not session):
        _bzyk83_plugin_updater = Bzyk83PluginUpdater(session)
    return _bzyk83_plugin_updater


_bzyk83_dashboard_init_before_update = Bzyk83Dashboard.__init__


def _bzyk83_dashboard_init_update(self, session):
    _bzyk83_dashboard_init_before_update(self, session)

    def first_shown():
        if first_shown in self.onShown:
            self.onShown.remove(first_shown)
        _bzyk83_get_plugin_updater(session).check()

    self.onShown.append(first_shown)


def _bzyk83_manual_plugin_update(self):
    _bzyk83_get_plugin_updater(self.session).install()


Bzyk83Dashboard.__init__ = _bzyk83_dashboard_init_update
DownloadListScreen.manual_plugin_update = _bzyk83_manual_plugin_update
