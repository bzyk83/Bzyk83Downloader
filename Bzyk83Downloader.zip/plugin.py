# -*- coding: ascii -*-
"""Pure Python first stage. It must run before the protected runtime exists."""
from Plugins.Plugin import PluginDescriptor
from enigma import eTimer
from .safe_update_ui import SafePluginUpdater, install as configure_updater
from .ipk_update import install as install_ipk

try:
    with open('/tmp/bzyk83_plugin_update.log','a') as _log:
        _log.write('Uruchomiono instalator przejsciowy 3.3.\n')
except OSError:pass

_updater=None

def main(session,**kwargs):
    global _updater
    if _updater is not None and _updater.session is session and _updater.busy:return
    configure_updater({'update_plugin':lambda:install_ipk('https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/plugin.update.json')})
    _updater=SafePluginUpdater(session)
    _updater.install()

def sessionstart(reason,session=None,**kwargs):
    if reason!=0 or session is None:return
    timer=eTimer()
    try:connection=timer.timeout.connect(lambda:main(session))
    except AttributeError:
        timer.callback.append(lambda:main(session));connection=None
    session._bzyk83_ipk_transition_timer=timer
    session._bzyk83_ipk_transition_connection=connection
    timer.start(2000,True)

def Plugins(**kwargs):
    return [PluginDescriptor(name='Bzyk83 Downloader',description='Instalacja aktualizacji 3.3',where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main),PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,fnc=sessionstart)]
