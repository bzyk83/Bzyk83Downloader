# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, configfile
from enigma import eTimer, gRGB
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
import time
import urllib.request
import ssl
import zipfile
import os
import glob
import datetime
import threading

PLUGIN_VERSION_URL = "https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/plugin.version"
PLUGIN_ZIP_URL = "https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/Bzyk83Downloader.zip"
PLUGIN_VERSION_FILE = "/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader/plugin.version"
PLUGIN_TMP = "/tmp/bzyk83_plugin.zip"

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader"

BACKUP_DIR = "/etc/enigma2/Bzyk83Backup"
MAX_BACKUPS = 5

VERSION_FILE = "/etc/enigma2/userbouquet.version"
LAST_UPDATE_FILE = "/etc/enigma2/.bzyk83_last_update"
PATH_ZIP = "/tmp/lista_kanalow.zip"
EXTRACT_PATH = "/etc/enigma2/"

LIST_URLS = {
    "hb": "https://raw.githubusercontent.com/bzyk83/listy/main/hb.zip",
    "dual": "https://raw.githubusercontent.com/bzyk83/listy/main/dual.zip",
    "3x1": "https://raw.githubusercontent.com/bzyk83/listy/main/3x1.zip",
    "4x1": "https://raw.githubusercontent.com/bzyk83/listy/main/4x1.zip",
    "5x1": "https://raw.githubusercontent.com/bzyk83/listy/main/5x1.zip",
    "6x1": "https://raw.githubusercontent.com/bzyk83/listy/main/6x1.zip"
}

VERSIONS_URL = "https://raw.githubusercontent.com/bzyk83/listy/main/versions.txt"

LIST_NAMES = {
    "hb": "HB 13E",
    "dual": "2x1 13E+19E",
    "3x1": "3x1 13E+19E+23E",
    "4x1": "4x1 13E+19E+23E+28E",
    "5x1": "5x1 13E+16E+19E+23E+28E",
    "6x1": "6x1 9E+13E+16E+19E+23E+28E"
}

def get_list_name(list_type):
    return LIST_NAMES.get(list_type, list_type)

config.plugins.bzyk83_downloader = ConfigSubsection()
config.plugins.bzyk83_downloader.autostart = ConfigYesNo(default=True)
config.plugins.bzyk83_downloader.last_list_type = ConfigSelection(
    default="dual",
    choices=[
        ("hb", "Hotbird 13E"),
        ("dual", "2x1 13E+19E"),
        ("3x1", "3x1 13E+19E+23E"),
        ("4x1", "4x1 13E+19E+23E+28E"),
        ("5x1", "5x1 13E+16E+19E+23E+28E"),
        ("6x1", "6x1 9E+13E+16E+19E+23E+28E")
    ]
)

def get_local_list_version():
    try:
        if os.path.exists(VERSION_FILE):
            with open(VERSION_FILE, "r") as f:
                return f.read().strip()
    except:
        pass
    return "Brak"

def get_last_update():
    try:
        if os.path.exists(LAST_UPDATE_FILE):
            with open(LAST_UPDATE_FILE, "r") as f:
                return f.read().strip()
    except:
        pass
    return "Brak danych"

def get_remote_version(list_type):
    try:
        req = urllib.request.Request(VERSIONS_URL)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            data = r.read().decode("utf-8")

        versions = {}

        for line in data.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                versions[key.strip()] = value.strip()

        return versions.get(list_type, "")

    except:
        return ""
        
def get_remote_plugin_version():
    try:
        req = urllib.request.Request(PLUGIN_VERSION_URL)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            version = r.read().decode("utf-8").strip()

        print("[Bzyk83] REMOTE PLUGIN VERSION =", version)

        return version

    except Exception as e:
        print("[Bzyk83] get_remote_plugin_version:", e)
        return ""
        

def get_local_plugin_version():
    try:
        with open(PLUGIN_VERSION_FILE, "r") as f:
            return f.read().strip()
    except:
        return "Brak"        
        
def delete_old_bouquets():
    patterns = [
        "userbouquet.*.tv",
        "userbouquet.*.radio",
        "bouquets.tv",
        "bouquets.radio"
    ]

    for pattern in patterns:
        for f in glob.glob(os.path.join(EXTRACT_PATH, pattern)):
            try:
                os.remove(f)
            except:
                pass

def safe_extract(zip_ref, destination):

    base = os.path.abspath(destination)

    for member in zip_ref.namelist():

        target = os.path.abspath(
            os.path.join(destination, member)
        )

        if not target.startswith(base + os.sep):
            raise Exception(
                "Niebezpieczna ścieżka w archiwum: %s" % member
            )

    zip_ref.extractall(destination)

def cleanup_old_backups():

    if not os.path.exists(BACKUP_DIR):
        return

    backups = sorted(
        glob.glob(os.path.join(BACKUP_DIR, "backup_*.zip"))
    )

    while len(backups) > MAX_BACKUPS:
        try:
            os.remove(backups[0])
        except:
            pass

        backups.pop(0)

def create_backup():

    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    filename = time.strftime(
        "backup_%Y-%m-%d_%H-%M.zip"
    )

    backup_file = os.path.join(
        BACKUP_DIR,
        filename
    )

    with zipfile.ZipFile(
        backup_file,
        "w",
        zipfile.ZIP_DEFLATED
    ) as zipf:

        for fname in os.listdir("/etc/enigma2"):

            if (
                fname.startswith("userbouquet.")
                or fname in (
                    "bouquets.tv",
                    "bouquets.radio",
                    "lamedb",
                    "lamedb5"
                )
            ):

                full = os.path.join(
                    "/etc/enigma2",
                    fname
                )

                if os.path.isfile(full):
                    zipf.write(
                        full,
                        fname
                    )

    cleanup_old_backups()

    return backup_file
    
def restore_backup(zip_path):

    with update_lock:

        if not os.path.exists(zip_path):
            raise Exception("Brak kopii")

        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            safe_extract(zip_ref, "/etc/enigma2")

        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 >/dev/null 2>&1")
        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 >/dev/null 2>&1")
        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=4 >/dev/null 2>&1")

def install_list(list_type):

    with update_lock:

        create_backup()

        url = LIST_URLS.get(list_type)

        if not url:
            raise Exception("Nieznany typ listy")

        try:
            if os.path.exists(PATH_ZIP):
                os.remove(PATH_ZIP)
        except:
            pass

        req = urllib.request.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0")

        ctx = ssl.create_default_context()

        with urllib.request.urlopen(req, context=ctx, timeout=20) as response:
            with open(PATH_ZIP, "wb") as out:
                out.write(response.read())

        if not zipfile.is_zipfile(PATH_ZIP):
            raise Exception("Uszkodzony plik ZIP")

        delete_old_bouquets()

        with zipfile.ZipFile(PATH_ZIP, "r") as zip_ref:
            safe_extract(zip_ref, EXTRACT_PATH)

        try:
            os.remove(PATH_ZIP)
        except:
            pass

        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

        with open(LAST_UPDATE_FILE, "w") as f:
            f.write(now)

        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 >/dev/null 2>&1")
        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 >/dev/null 2>&1")
        os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=4 >/dev/null 2>&1")
    
def update_plugin():

    with update_lock:

        try:

            req = urllib.request.Request(PLUGIN_ZIP_URL)
            req.add_header("User-Agent", "Mozilla/5.0")

            ctx = ssl.create_default_context()

            with urllib.request.urlopen(
                req,
                context=ctx,
                timeout=20
            ) as response:

                with open(PLUGIN_TMP, "wb") as out:
                    out.write(response.read())

            if not zipfile.is_zipfile(PLUGIN_TMP):
                raise Exception("Uszkodzony plik ZIP")

            with zipfile.ZipFile(PLUGIN_TMP, "r") as zip_ref:
                safe_extract(zip_ref, PLUGIN_PATH)

            return True

        except Exception as e:

            print("[Bzyk83] Plugin update error:", e)
            return False

        finally:

            try:
                if os.path.exists(PLUGIN_TMP):
                    os.remove(PLUGIN_TMP)
            except Exception as e:
                print("[Bzyk83] Cannot remove temp file:", e)
        
class DownloadListScreen(Screen):

    skin = """
    <screen position="center,center" size="1000,540" title="Bzyk83 Downloader">
        <widget name="status" position="20,20" size="960,50" font="Regular;30" halign="center"/>
        <widget name="info" position="20,90" size="960,40" font="Regular;24" halign="center"/>
        <widget name="update_info" position="20,140" size="960,40" font="Regular;24" halign="center"/>
        <widget name="last_update" position="20,190" size="960,40" font="Regular;24" halign="center"/>
        <widget name="plugin_version"
                position="20,240"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="plugin_update"
                position="20,280"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="autostart_status"
                position="20,320"
                size="960,40"
                font="Regular;24"
                halign="center"/>

        <widget name="key_red" position="20,420" size="220,50"
    backgroundColor="red"
    font="Regular;28"
    halign="center"
    valign="center"/>
        <widget name="key_green" position="260,420" size="220,50" backgroundColor="green"
    font="Regular;28" halign="center" valign="center"/>

        <widget name="key_yellow" position="500,420" size="220,50" backgroundColor="yellow"
    font="Regular;28" halign="center" valign="center"/>

        <widget name="key_blue" position="740,420" size="220,50" backgroundColor="blue"
    font="Regular;28" halign="center" valign="center"/>
  
        <widget name="key_menu"
                position="20,485"
                size="960,30"
                font="Regular;22"
                halign="center"
                valign="center"/>

  </screen>
    """
    
    def blue_action(self):

        if self.plugin_update_available:
            self.manual_plugin_update()
        else:
            self.toggle_autostart()

    def __init__(self, session):
        Screen.__init__(self, session)

        self["status"] = Label("Wtyczka gotowa")
        self["info"] = Label("")
        self["update_info"] = Label("")
        self["last_update"] = Label("")
        self["plugin_version"] = Label("")
        self["plugin_update"] = Label("")
        self["autostart_status"] = Label("")

        self["key_red"] = Label("Wyjście")
        self["key_green"] = Label("Wybór listy")
        self["key_yellow"] = Label("Pobierz")
        self["key_blue"] = Label("Autostart")
        self["key_menu"] = Label("")
                       
        self.plugin_update_available = False

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "red": self.close,
                "green": self.select_list,
                "yellow": self.download_selected_list,
                "blue": self.blue_action,
                "menu": self.open_menu,
                "cancel": self.close
            },
            -1
        )

        self.onLayoutFinish.append(self.layoutFinished)
        
        self.guiTimer = eTimer()

        try:
            self.guiTimer.timeout.connect(self.guiUpdate)
        except:
            self.guiTimer.callback.append(self.guiUpdate)

        self.guiAction = None
        
    def guiUpdate(self):

        if self.guiAction == "done":
            self.refresh_version_status()
            self.update_autostart_label()
            self["status"].setText("Gotowe.")

        elif self.guiAction and self.guiAction.startswith("error:"):
            self["status"].setText(
                self.guiAction[6:]
            )        

    def layoutFinished(self):
        self.refresh_version_status()
        self.update_autostart_label()
        self.update_backup_label()

        if self["key_menu"].instance:
            self["key_menu"].instance.setForegroundColor(
                gRGB(0x66CCFF)
            )
                        
    def refresh_version_status(self):

        list_type = config.plugins.bzyk83_downloader.last_list_type.value

        mode_name = LIST_NAMES.get(list_type, list_type)

        local_version = get_local_list_version()
        remote_version = get_remote_version(list_type)

        local_plugin = get_local_plugin_version()
        remote_plugin = get_remote_plugin_version()

        self["status"].setText(
            "Aktywna lista: %s" % mode_name
        )

        self["info"].setText(
            "Wersja zainstalowana: %s" % local_version
        )

        if not remote_version:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0xFF0000)
                )

            txt = "brak połączenia"

        elif local_version == remote_version:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0xFFFFFF)
                )

            txt = "aktualna (%s)" % remote_version

        else:

            if self["update_info"].instance:
                self["update_info"].instance.setForegroundColor(
                    gRGB(0x00FF00)
                )

            txt = "NOWA (%s)" % remote_version

        self["update_info"].setText(
            "Dostępna aktualizacja: %s" % txt
        )

        self["last_update"].setText(
            "Ostatnia aktualizacja: %s" % get_last_update()
        )

        self["plugin_version"].setText(
            "Wersja wtyczki: %s" % local_plugin
        )

        if not remote_plugin:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0xFF0000)
                )

            self["plugin_update"].setText(
                "Aktualizacja wtyczki: brak połączenia"
            )

            self.plugin_update_available = False
            self["key_blue"].setText("Autostart")

        elif remote_plugin == local_plugin:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0xFFFFFF)
                )

            self["plugin_update"].setText(
                "Aktualizacja wtyczki: aktualna (%s)" % remote_plugin
            )

            self.plugin_update_available = False
            self["key_blue"].setText("Autostart")

        else:

            if self["plugin_update"].instance:
                self["plugin_update"].instance.setForegroundColor(
                    gRGB(0x00FF00)
                )

            self["plugin_update"].setText(
                "Dostępna aktualizacja: %s" % remote_plugin
            )

            self.plugin_update_available = True
            self["key_blue"].setText("Aktualizuj")

    def open_menu(self):

        self.session.openWithCallback(
            self.menu_callback,
            ChoiceBox,
            title="Bzyk83 Downloader",
            list=[
                ("Utwórz kopię list", "backup"),
                ("Przywróć kopię", "restore"),
                ("Usuń wszystkie kopie", "delete")
            ]
        )

    def menu_callback(self, choice):

        if not choice:
            return

        action = choice[1]

        if action == "backup":

            try:

                path = create_backup()

                self.update_backup_label()

                self.session.open(
                    MessageBox,
                    "Kopia utworzona:\n%s" %
                    os.path.basename(path),
                    MessageBox.TYPE_INFO
                )

            except Exception as e:

                self.session.open(
                    MessageBox,
                    str(e),
                    MessageBox.TYPE_ERROR
                )

        elif action == "restore":

            self.show_backup_list()

        elif action == "delete":

            count = 0

            for f in glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            ):

                try:
                    os.remove(f)
                    count += 1
                except:
                    pass

            self.update_backup_label()

            self.session.open(
                MessageBox,
                "Usunięto %d kopii." % count,
                MessageBox.TYPE_INFO
            )
    
    def update_autostart_label(self):
        enabled = config.plugins.bzyk83_downloader.autostart.value
        mode = config.plugins.bzyk83_downloader.last_list_type.value

        mode_name = LIST_NAMES.get(mode, mode)

        self["autostart_status"].setText(
            "Autostart: %s (%s)" %
            ("WŁ" if enabled else "WYŁ", mode_name)
        )

    def update_backup_label(self):

        count = len(
            glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            )
        )

        self["key_menu"].setText(
            "MENU ➜ Zarządzanie kopiami (%d)" % count
        )

    def select_list(self):

        current = config.plugins.bzyk83_downloader.last_list_type.value

        choices = []

        for key in ["hb", "dual", "3x1", "4x1", "5x1", "6x1"]:

            label = LIST_NAMES.get(key, key)

            if key == current:
                label = "✓ " + label

            choices.append((label, key))

        self.session.openWithCallback(
            self.select_list_callback,
            ChoiceBox,
            title="Wybierz listę kanałów",
            list=choices
        )
        
    def select_list_callback(self, choice):

        if not choice:
            return

        config.plugins.bzyk83_downloader.last_list_type.value = choice[1]
        config.plugins.bzyk83_downloader.last_list_type.save()

        configfile.save()

        self.refresh_version_status()
        self.update_autostart_label()

    def download_selected_list(self):
        self.start_download(
            config.plugins.bzyk83_downloader.last_list_type.value
        )

    def manual_plugin_update(self):

        self["status"].setText("Aktualizacja wtyczki...")

        if update_plugin():

            self["status"].setText(
                "Restart GUI..."
            )

            os.system("sync")
            os.system("killall -9 enigma2")

        else:

            self["status"].setText(
                "Błąd aktualizacji"
            )

    def toggle_autostart(self):
        config.plugins.bzyk83_downloader.autostart.value = (
            not config.plugins.bzyk83_downloader.autostart.value
        )

        config.plugins.bzyk83_downloader.autostart.save()
        configfile.save()

        self.update_autostart_label()
        self.refresh_version_status()

    def start_download(self, list_type):

        config.plugins.bzyk83_downloader.last_list_type.value = list_type
        config.plugins.bzyk83_downloader.last_list_type.save()

        configfile.save()

        threading.Thread(
            target=self.worker,
            args=(list_type,),
            daemon=True
        ).start()

    def worker(self, list_type):

        try:

            install_list(list_type)

            self.guiAction = "done"
            self.guiTimer.start(100, True)

        except Exception as e:

            self.guiAction = "error:Błąd: %s" % str(e)
            self.guiTimer.start(100, True)

    def show_backup_list(self):

        backups = sorted(
            glob.glob(
                os.path.join(
                    BACKUP_DIR,
                    "backup_*.zip"
                )
            ),
            reverse=True
        )

        if not backups:

            self.session.open(
                MessageBox,
                "Brak kopii.",
                MessageBox.TYPE_INFO
            )

            return

        choices = []

        for f in backups:

            choices.append(
                (
                    os.path.basename(f),
                    f
                )
            )

        self.session.openWithCallback(
            self.restore_selected_backup,
            ChoiceBox,
            title="Wybierz kopię",
            list=choices
        )

    def restore_selected_backup(self, choice):

        if not choice:
            return

        self.selected_backup = choice[1]

        self.session.openWithCallback(
            self.restore_confirmed,
            MessageBox,
            "Przywrócić kopię:\n%s ?" %
            os.path.basename(choice[1]),
            MessageBox.TYPE_YESNO
        )
        
    def restore_confirmed(self, answer):

        if not answer:
            return

        try:

            restore_backup(self.selected_backup)

            self.session.open(
                MessageBox,
                "Kopia została przywrócona.",
                MessageBox.TYPE_INFO
            )

            self.refresh_version_status()
         
            self.update_backup_label()
            
            self.update_autostart_label()

        except Exception as e:

            self.session.open(
                MessageBox,
                str(e),
                MessageBox.TYPE_ERROR
            )        
        
def main(session, **kwargs):
    session.open(DownloadListScreen)

def silent_autostart_update():
    if not config.plugins.bzyk83_downloader.autostart.value:
        return

    list_type = config.plugins.bzyk83_downloader.last_list_type.value

    local_version = get_local_list_version()
    remote_version = get_remote_version(list_type)

    if not remote_version:
        return

    if local_version == remote_version:
        return

    try:
        install_list(list_type)
        print("[Bzyk83] Zaktualizowano listę do wersji %s" % remote_version)
    except:
        pass

gTimer = None
update_lock = threading.Lock()

def timer_callback():
    global gTimer

    threading.Thread(
        target=silent_autostart_update,
        daemon=True
    ).start()

    gTimer.start(43200000, True)

def autostart(reason, **kwargs):
    global gTimer

    if reason == 0:
        gTimer = eTimer()

        try:
            gTimer.timeout.connect(timer_callback)
        except:
            gTimer.callback.append(timer_callback)

        gTimer.start(43200000, True)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Bzyk83 Downloader",
            description="Aktualizacja list kanałów",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]
