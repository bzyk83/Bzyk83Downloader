try:
    import sys as _sys,importlib as _il
    _sys.path.insert(0,'/usr/lib/bzyk83-protected')
    _bz_main=(__name__=='__main__')
    if __package__:
        _bz_core=_il.import_module('._bz_033d63be6bbf7aaa',__package__)
    else:
        _sys.path.insert(0,'/usr/lib/enigma2/python')
        _bz_core=_il.import_module('Plugins.Extensions.Bzyk83Downloader._bz_033d63be6bbf7aaa')
    globals().update({k:v for k,v in vars(_bz_core).items() if not k.startswith('__')})
    if _bz_main and hasattr(_bz_core,'_bzyk83_entry'):_bz_core._bzyk83_entry()
except ImportError:
    from .ipk_transition import Plugins,main
else:
    import os as _transition_os
    _transition_check=Bzyk83PluginUpdater.check
    def _transition_pending_check(self):
        if _transition_os.path.isfile("/usr/lib/enigma2/python/Plugins/Extensions/Bzyk83Downloader/.ipk-transition-pending"):
            return self.install()
        return _transition_check(self)
    Bzyk83PluginUpdater.check=_transition_pending_check
