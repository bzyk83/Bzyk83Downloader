import sys as _sys,importlib as _il
_sys.path.insert(0,'/usr/lib/bzyk83-protected')
_bz_main=(__name__=='__main__')
if __package__:
    _bz_core=_il.import_module('._bz_abae91eb649b4754',__package__)
else:
    _sys.path.insert(0,'/usr/lib/enigma2/python')
    _bz_core=_il.import_module('Plugins.Extensions.Bzyk83Downloader._bz_abae91eb649b4754')
globals().update({k:v for k,v in vars(_bz_core).items() if not k.startswith('__')})
if _bz_main and hasattr(_bz_core,'_bzyk83_entry'):_bz_core._bzyk83_entry()
