# -*- coding: ascii -*-
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Console import Console
import os,sys,shlex

def main(session,**kwargs):
    state={};console=Console();state['console']=console
    progress=session.open(MessageBox,'Dostosowanie instalacji do aktualizacji IPK...',MessageBox.TYPE_INFO,enable_input=False)
    def finished(output,code,extra=None):
        progress.close()
        if code==0:
            session.openWithCallback(lambda *a:session.open(TryQuitMainloop,3),MessageBox,'Pakiet IPK zainstalowany. Restart GUI.',MessageBox.TYPE_INFO,timeout=5,enable_input=False)
        else:
            session.open(MessageBox,'Nie zainstalowano pakietu IPK.\nSzczegoly: /tmp/bzyk83_plugin_update.log\nSprawdz zaleznosci oraz dostep do GitHuba.',MessageBox.TYPE_ERROR)
        state.clear()
    script=os.path.join(os.path.dirname(__file__),'ipk_transition_install.py')
    console.ePopen(shlex.join([sys.executable,'-u',script]),finished)
    progress._bzyk83_transition_state=state

def Plugins(**kwargs):
    return [PluginDescriptor(name='Bzyk83 Downloader - instalacja IPK',description='Dokoncz przejscie na aktualizacje IPK',where=PluginDescriptor.WHERE_PLUGINMENU,fnc=main), PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,fnc=sessionstart)]

def sessionstart(reason,session=None,**kwargs):
    if reason==0 and session is not None:
        from enigma import eTimer
        timer=eTimer()
        try:timer.timeout.connect(lambda:main(session))
        except AttributeError:timer.callback.append(lambda:main(session))
        session._bzyk83_ipk_transition_timer=timer
        timer.start(2000,True)
