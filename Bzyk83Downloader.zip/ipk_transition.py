# -*- coding: ascii -*-
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Console import Console
import os,sys,shlex

def main(session,**kwargs):
    from . import safe_update_ui as ui
    from .ipk_update import install as install_ipk
    previous=getattr(session,'_bzyk83_transition_updater',None)
    if previous is not None and previous.busy:return
    ui.install({'update_plugin':lambda:install_ipk('https://raw.githubusercontent.com/bzyk83/Bzyk83Downloader/main/plugin.update.json')})
    updater=ui.SafePluginUpdater(session)
    session._bzyk83_transition_updater=updater
    updater.install()

def Plugins(**kwargs):
    return [PluginDescriptor(name='Bzyk83 Downloader - instalacja IPK',description='Dokoncz przejscie na aktualizacje IPK',where=PluginDescriptor.WHERE_PLUGINMENU,fnc=main), PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,fnc=sessionstart)]

def sessionstart(reason,session=None,**kwargs):
    if reason==0 and session is not None:
        from enigma import eTimer
        timer=eTimer()
        try:timer.timeout.connect(lambda:main(session))
        except AttributeError:timer.callback.append(lambda:main(session))
        session._bzyk83_ipk_transition_timer=timer
        timer.start(2000,True)
