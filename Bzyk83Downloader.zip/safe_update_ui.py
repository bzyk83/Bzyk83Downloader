# -*- coding: ascii -*-
"""Enigma-safe asynchronous updater: all modal transitions run on a ready session."""
import threading,re,subprocess,shutil
from enigma import eTimer
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
_host=None

def _connect(timer,callback):
    try:return timer.timeout.connect(callback)
    except AttributeError:timer.callback.append(callback);return None

class SafePluginUpdater:
    def __init__(self,session):
        self.session=session;self.busy=False;self.result=None;self.mode=None;self.progress=None
        self.timer=eTimer();self.connection=_connect(self.timer,self.tick)
        self.modal_timer=eTimer();self.modal_connection=_connect(self.modal_timer,self.modal_tick)
        self.pending=[]

    @staticmethod
    def newer(remote,local):
        remote=str(remote).strip().lstrip('vV');local=str(local).strip().lstrip('vV')
        if not all(re.fullmatch(r'[0-9][A-Za-z0-9.+:~_-]*',s) for s in (remote,local)):return False
        if shutil.which('opkg'):
            return subprocess.run(['opkg','compare-versions',remote,'>',local],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
        return tuple(map(int,re.findall(r'\d+',remote)))>tuple(map(int,re.findall(r'\d+',local)))

    def defer(self,callback,*args):
        self.pending.append((callback,args));self.modal_timer.start(1,True)

    def ready(self):
        return getattr(self.session,'current_dialog',None) is None or bool(getattr(self.session,'in_exec',False))

    def modal_tick(self):
        if getattr(self.session,'shutdown',False):self.pending=[];self.busy=False;return
        if not self.pending:return
        if not self.ready():self.modal_timer.start(100,True);return
        callback,args=self.pending.pop(0)
        try:callback(*args)
        except RuntimeError as error:
            if 'Modal open' in str(error):
                self.pending.insert(0,(callback,args));self.modal_timer.start(100,True);return
            self.busy=False
            print('[Bzyk83 update] '+str(error))
        except Exception as error:
            self.busy=False
            print('[Bzyk83 update] '+type(error).__name__+': '+str(error))
        if self.pending:self.modal_timer.start(1,True)

    def check(self):
        if self.busy:return
        self.busy=True;self.mode='check';self.result=None
        def worker():
            try:self.result=(_host['get_remote_plugin_version'](),_host['get_local_plugin_version']())
            except Exception:self.result=('','')
        threading.Thread(target=worker,daemon=True).start();self.timer.start(250,True)

    def tick(self):
        if getattr(self.session,'shutdown',False):self.busy=False;return
        if self.result is None:self.timer.start(250,True);return
        if self.mode=='install':
            # An unrelated modal dialog can temporarily cover the progress screen.
            if not self.ready() or getattr(self.session,'current_dialog',None) is not self.progress:
                self.timer.start(100,True);return
            result=self.result;self.result=None;self.progress.close(bool(result[0]));return
        result=self.result;self.result=None
        remote,local=result
        if self.newer(remote,local):self.defer(self.confirm,remote,local)
        else:self.busy=False

    def confirm(self,remote,local):
        self.session.openWithCallback(self.answer,MessageBox,'Dostepna aktualizacja wtyczki.\n\nZainstalowana: %s\nNowa: %s\n\nZainstalowac? Po instalacji nastapi restart GUI.'%(local,remote),MessageBox.TYPE_YESNO,default=False)

    def answer(self,yes):
        self.busy=False
        if yes:self.install()

    def install(self):
        if self.busy:return
        self.busy=True;self.mode='install';self.result=None;self.defer(self.begin_install)

    def begin_install(self):
        self.progress=self.session.openWithCallback(self.installed,MessageBox,'Trwa aktualizacja wtyczki...',MessageBox.TYPE_INFO,timeout=0,enable_input=False)
        def worker():
            try:self.result=(bool(_host['update_plugin']()),)
            except Exception:self.result=(False,)
        threading.Thread(target=worker,daemon=True).start();self.timer.start(250,True)

    def installed(self,success=False):
        self.progress=None;self.defer(self.show_result,bool(success))

    def show_result(self,success):
        if success:
            self.session.openWithCallback(self.restart,MessageBox,'Wtyczka zostala zaktualizowana.\nZa 5 sekund nastapi restart GUI.',MessageBox.TYPE_INFO,timeout=5,enable_input=False)
        else:
            self.busy=False
            self.session.open(MessageBox,'Aktualizacja nie powiodla sie. GUI nie zostanie zrestartowane.\nSzczegoly: /tmp/bzyk83_plugin_update.log',MessageBox.TYPE_ERROR,timeout=8)

    def restart(self,*args):self.defer(self.do_restart)
    def do_restart(self):self.session.open(TryQuitMainloop,3)


def install(engine):
    global _host
    _host=engine
    scopes=[engine]
    core=engine.get('_bz_core')
    if core is not None and hasattr(core,'__dict__'):scopes.append(core.__dict__)
    for scope in scopes:
        scope['Bzyk83PluginUpdater']=SafePluginUpdater;scope['_bzyk83_plugin_updater']=None
    def checked(owner):
        engine['_bzyk83_get_plugin_updater'](owner.session).check()
    # Replace the older check dialog chain too: it opened a second modal window
    # while the timed status window was still closing.
    for name in ('DownloadListScreen','Bzyk83Dashboard'):
        cls=engine.get(name)
        if cls is not None:cls.dashboard_plugin_update=checked
