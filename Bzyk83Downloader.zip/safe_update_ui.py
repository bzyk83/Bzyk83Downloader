import sys as _sys,importlib as _il
_sys.path.insert(0,'/usr/lib/bzyk83-protected')
if __package__:
    _bz_core=_il.import_module('._bz_a858e727221e35c2',__package__)
else:
    _sys.path.insert(0,'/usr/lib/enigma2/python')
    _bz_core=_il.import_module('Plugins.Extensions.Bzyk83Downloader._bz_a858e727221e35c2')
globals().update({k:v for k,v in vars(_bz_core).items() if not k.startswith('__')})
